--
-- PostgreSQL database dump
--

\restrict RexRrAuY1MRx7cXieJPggk8sbPuPWOp3jsP8obLPIl13AuxiVsmgMg2HapBNM4U

-- Dumped from database version 14.19 (Ubuntu 14.19-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.19 (Ubuntu 14.19-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.stock_out_history DROP CONSTRAINT IF EXISTS stock_out_history_machine_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_out_history DROP CONSTRAINT IF EXISTS stock_out_history_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sales DROP CONSTRAINT IF EXISTS sales_machine_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sales DROP CONSTRAINT IF EXISTS sales_franchise_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sales DROP CONSTRAINT IF EXISTS sales_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.price_history DROP CONSTRAINT IF EXISTS price_history_franchise_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.machines DROP CONSTRAINT IF EXISTS machines_franchise_id_fkey;
ALTER TABLE IF EXISTS ONLY public.machine_payments DROP CONSTRAINT IF EXISTS machine_payments_machine_id_fkey;
ALTER TABLE IF EXISTS ONLY public.machine_payments DROP CONSTRAINT IF EXISTS machine_payments_invoice_id_fkey;
ALTER TABLE IF EXISTS ONLY public.machine_payments DROP CONSTRAINT IF EXISTS machine_payments_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.machine_payments DROP CONSTRAINT IF EXISTS machine_payments_bank_id_fkey;
ALTER TABLE IF EXISTS ONLY public.machine_expenses DROP CONSTRAINT IF EXISTS machine_expenses_machine_id_fkey;
ALTER TABLE IF EXISTS ONLY public.machine_expenses DROP CONSTRAINT IF EXISTS machine_expenses_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.machine_expenses DROP CONSTRAINT IF EXISTS machine_expenses_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.machine_expenses DROP CONSTRAINT IF EXISTS machine_expenses_bank_id_fkey;
ALTER TABLE IF EXISTS ONLY public.machine_counters DROP CONSTRAINT IF EXISTS machine_counters_machine_id_fkey;
ALTER TABLE IF EXISTS ONLY public.machine_counters DROP CONSTRAINT IF EXISTS machine_counters_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.franchises DROP CONSTRAINT IF EXISTS franchises_payment_bank_id_fkey;
ALTER TABLE IF EXISTS ONLY public.franchise_agreements DROP CONSTRAINT IF EXISTS franchise_agreements_franchise_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS fk_users_franchise;
ALTER TABLE IF EXISTS ONLY public.bank_money_logs DROP CONSTRAINT IF EXISTS bank_money_logs_bank_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_changed_by_fkey;
ALTER TABLE IF EXISTS ONLY public.attachments DROP CONSTRAINT IF EXISTS attachments_franchise_id_fkey;
DROP TRIGGER IF EXISTS trigger_auto_invoice_number ON public.sales;
DROP INDEX IF EXISTS public.idx_stock_out_machine_id;
DROP INDEX IF EXISTS public.idx_stock_out_item_id;
DROP INDEX IF EXISTS public.idx_stock_out_date;
DROP INDEX IF EXISTS public.idx_sales_payment_status;
DROP INDEX IF EXISTS public.idx_sales_machine_id;
DROP INDEX IF EXISTS public.idx_sales_invoice_number;
DROP INDEX IF EXISTS public.idx_sales_franchise_id;
DROP INDEX IF EXISTS public.idx_notifications_user_id;
DROP INDEX IF EXISTS public.idx_notifications_status;
DROP INDEX IF EXISTS public.idx_notifications_created_at;
DROP INDEX IF EXISTS public.idx_machines_franchise_id;
DROP INDEX IF EXISTS public.idx_machine_payments_machine_id;
DROP INDEX IF EXISTS public.idx_machine_payments_invoice_id;
DROP INDEX IF EXISTS public.idx_machine_expenses_machine_id;
DROP INDEX IF EXISTS public.idx_machine_expenses_bank_id;
DROP INDEX IF EXISTS public.idx_machine_counters_machine_id;
DROP INDEX IF EXISTS public.idx_inventory_transactions_item_id;
DROP INDEX IF EXISTS public.idx_franchises_payment_bank_id;
DROP INDEX IF EXISTS public.idx_bank_money_logs_date;
DROP INDEX IF EXISTS public.idx_bank_money_logs_bank_id;
DROP INDEX IF EXISTS public.idx_audit_logs_table_record;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.stock_out_history DROP CONSTRAINT IF EXISTS stock_out_history_pkey;
ALTER TABLE IF EXISTS ONLY public.sales DROP CONSTRAINT IF EXISTS sales_pkey;
ALTER TABLE IF EXISTS ONLY public.price_history DROP CONSTRAINT IF EXISTS price_history_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.machines DROP CONSTRAINT IF EXISTS machines_pkey;
ALTER TABLE IF EXISTS ONLY public.machine_payments DROP CONSTRAINT IF EXISTS machine_payments_pkey;
ALTER TABLE IF EXISTS ONLY public.machine_expenses DROP CONSTRAINT IF EXISTS machine_expenses_pkey;
ALTER TABLE IF EXISTS ONLY public.machine_expenses DROP CONSTRAINT IF EXISTS machine_expenses_expense_number_key;
ALTER TABLE IF EXISTS ONLY public.machine_counters DROP CONSTRAINT IF EXISTS machine_counters_pkey;
ALTER TABLE IF EXISTS ONLY public.ledger_entries DROP CONSTRAINT IF EXISTS ledger_entries_pkey;
ALTER TABLE IF EXISTS ONLY public.inventory_transactions DROP CONSTRAINT IF EXISTS inventory_transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.franchises DROP CONSTRAINT IF EXISTS franchises_pkey;
ALTER TABLE IF EXISTS ONLY public.franchise_agreements DROP CONSTRAINT IF EXISTS franchise_agreements_pkey;
ALTER TABLE IF EXISTS ONLY public.expense_categories DROP CONSTRAINT IF EXISTS expense_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.expense_categories DROP CONSTRAINT IF EXISTS expense_categories_category_name_key;
ALTER TABLE IF EXISTS ONLY public.banks DROP CONSTRAINT IF EXISTS banks_pkey;
ALTER TABLE IF EXISTS ONLY public.bank_money_logs DROP CONSTRAINT IF EXISTS bank_money_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.attachments DROP CONSTRAINT IF EXISTS attachments_pkey;
ALTER TABLE IF EXISTS public.expense_categories ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.stock_out_history;
DROP TABLE IF EXISTS public.sales;
DROP TABLE IF EXISTS public.price_history;
DROP TABLE IF EXISTS public.notifications;
DROP TABLE IF EXISTS public.machines;
DROP TABLE IF EXISTS public.machine_payments;
DROP TABLE IF EXISTS public.machine_expenses;
DROP TABLE IF EXISTS public.machine_counters;
DROP TABLE IF EXISTS public.ledger_entries;
DROP TABLE IF EXISTS public.inventory_transactions;
DROP TABLE IF EXISTS public.franchises;
DROP TABLE IF EXISTS public.franchise_agreements;
DROP SEQUENCE IF EXISTS public.expense_categories_id_seq;
DROP TABLE IF EXISTS public.expense_categories;
DROP TABLE IF EXISTS public.banks;
DROP TABLE IF EXISTS public.bank_money_logs;
DROP TABLE IF EXISTS public.audit_logs;
DROP TABLE IF EXISTS public.attachments;
DROP FUNCTION IF EXISTS public.generate_unique_invoice_number(p_sales_date date, p_franchise_id uuid, p_machine_id uuid);
DROP FUNCTION IF EXISTS public.generate_invoice_number(p_year integer);
DROP FUNCTION IF EXISTS public.auto_generate_invoice_number();
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS pgcrypto;
--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: auto_generate_invoice_number(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.auto_generate_invoice_number() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    franchise_id_val UUID;
BEGIN
    IF NEW.invoice_number IS NULL OR NEW.invoice_number = '' THEN
        -- Get franchise_id
        IF NEW.franchise_id IS NOT NULL THEN
            franchise_id_val := NEW.franchise_id;
        ELSIF NEW.machine_id IS NOT NULL THEN
            SELECT m.franchise_id INTO franchise_id_val
            FROM machines m
            WHERE m.id = NEW.machine_id;
        END IF;
        
        NEW.invoice_number := generate_unique_invoice_number(NEW.sales_date, franchise_id_val, NEW.machine_id);
    END IF;
    
    RETURN NEW;
END;
$$;


--
-- Name: generate_invoice_number(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.generate_invoice_number(p_year integer) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    next_seq INTEGER;
    invoice_num TEXT;
BEGIN
    -- Get the next sequence number for the year
    SELECT COALESCE(MAX(CAST(SPLIT_PART(invoice_number, '/', 3) AS INTEGER)), 0) + 1
    INTO next_seq
    FROM sales 
    WHERE invoice_number LIKE 'clw/' || p_year || '/%';
    
    -- Format the invoice number
    invoice_num := 'clw/' || p_year || '/' || LPAD(next_seq::TEXT, 3, '0');
    
    RETURN invoice_num;
END;
$$;


--
-- Name: generate_unique_invoice_number(date, uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.generate_unique_invoice_number(p_sales_date date DEFAULT NULL::date, p_franchise_id uuid DEFAULT NULL::uuid, p_machine_id uuid DEFAULT NULL::uuid) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    current_year INTEGER;
    current_month INTEGER;
    current_day INTEGER;
    invoice_num TEXT;
    payment_duration TEXT;
    machine_number TEXT;
    clean_machine_number TEXT;
BEGIN
    IF p_sales_date IS NULL THEN
        p_sales_date := CURRENT_DATE;
    END IF;
    
    current_year := EXTRACT(YEAR FROM p_sales_date);
    current_month := EXTRACT(MONTH FROM p_sales_date);
    current_day := EXTRACT(DAY FROM p_sales_date);
    
    -- Get machine number
    IF p_machine_id IS NOT NULL THEN
        SELECT m.machine_number INTO machine_number
        FROM machines m
        WHERE m.id = p_machine_id;
        
        -- Clean machine number: remove 'M' prefix and pad to 2 digits
        clean_machine_number := LPAD(REGEXP_REPLACE(COALESCE(machine_number, '0'), '^M', '', 'i'), 2, '0');
    ELSE
        clean_machine_number := '00';
    END IF;
    
    -- Get franchise payment duration - check both direct franchise_id and via machine
    IF p_franchise_id IS NOT NULL THEN
        SELECT f.payment_duration INTO payment_duration
        FROM franchises f
        WHERE f.id = p_franchise_id;
    ELSIF p_machine_id IS NOT NULL THEN
        SELECT f.payment_duration INTO payment_duration
        FROM franchises f
        JOIN machines m ON m.franchise_id = f.id
        WHERE m.id = p_machine_id;
    END IF;
    
    -- Debug log
    RAISE NOTICE 'Payment Duration: %, Machine: %, Date: %', payment_duration, clean_machine_number, p_sales_date;
    
    -- Generate invoice based on payment duration
    IF payment_duration = 'Half Monthly' THEN
        -- Half monthly: clw/01/2025/01H1 or clw/01/2025/01H2
        IF current_day <= 15 THEN
            invoice_num := 'clw/' || clean_machine_number || '/' || current_year || '/' || LPAD(current_month::TEXT, 2, '0') || 'H1';
        ELSE
            invoice_num := 'clw/' || clean_machine_number || '/' || current_year || '/' || LPAD(current_month::TEXT, 2, '0') || 'H2';
        END IF;
    ELSE
        -- Monthly: clw/01/2025/01 (month number)
        invoice_num := 'clw/' || clean_machine_number || '/' || current_year || '/' || LPAD(current_month::TEXT, 2, '0');
    END IF;
    
    RAISE NOTICE 'Generated Invoice: %', invoice_num;
    
    RETURN invoice_num;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    franchise_id uuid,
    file_name character varying(255) NOT NULL,
    file_url text NOT NULL,
    file_type character varying(100) NOT NULL,
    file_size integer,
    mime_type character varying(100),
    uploaded_at timestamp with time zone DEFAULT now()
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    table_name character varying(100) NOT NULL,
    record_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    old_data jsonb,
    new_data jsonb,
    changed_by uuid,
    changed_at timestamp with time zone DEFAULT now()
);


--
-- Name: bank_money_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bank_money_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bank_id uuid NOT NULL,
    action_type character varying(10) NOT NULL,
    amount numeric(15,2) NOT NULL,
    transaction_date date NOT NULL,
    remarks text,
    created_by character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT bank_money_logs_action_type_check CHECK (((action_type)::text = ANY ((ARRAY['add'::character varying, 'deduct'::character varying])::text[])))
);


--
-- Name: banks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.banks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    bank_name character varying(255) NOT NULL,
    account_number character varying(100),
    account_holder_name character varying(255),
    branch_name character varying(255),
    routing_number character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: expense_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expense_categories (
    id integer NOT NULL,
    category_name character varying(255) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: expense_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.expense_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: expense_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.expense_categories_id_seq OWNED BY public.expense_categories.id;


--
-- Name: franchise_agreements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.franchise_agreements (
    id uuid NOT NULL,
    franchise_id uuid,
    effective_date date,
    coin_price numeric,
    doll_price numeric,
    franchise_share integer,
    clowee_share integer,
    electricity_cost numeric,
    vat_percentage numeric,
    payment_duration character varying,
    notes text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: franchises; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.franchises (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    coin_price numeric(10,2) NOT NULL,
    doll_price numeric(10,2) NOT NULL,
    electricity_cost numeric(10,2) NOT NULL,
    vat_percentage numeric(5,2),
    franchise_share numeric(5,2) NOT NULL,
    clowee_share numeric(5,2) NOT NULL,
    payment_duration character varying(50) NOT NULL,
    maintenance_percentage numeric(5,2),
    security_deposit_type character varying(100),
    security_deposit_notes text,
    agreement_copy text,
    trade_nid_copy text[],
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    payment_bank_id uuid
);


--
-- Name: inventory_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    item_id uuid,
    transaction_type character varying(50) NOT NULL,
    quantity integer NOT NULL,
    transaction_date date NOT NULL,
    related_invoice uuid,
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: ledger_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ledger_entries (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    entry_date date NOT NULL,
    type character varying(100) NOT NULL,
    debit numeric(10,2) DEFAULT 0,
    credit numeric(10,2) DEFAULT 0,
    balance numeric(10,2),
    description text,
    reference_id uuid,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: machine_counters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.machine_counters (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    machine_id uuid,
    reading_date date NOT NULL,
    coin_counter integer NOT NULL,
    prize_counter integer NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    created_by uuid
);


--
-- Name: machine_expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.machine_expenses (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    machine_id uuid,
    expense_date date NOT NULL,
    expense_details text NOT NULL,
    quantity integer DEFAULT 1,
    item_price numeric(10,2) DEFAULT 0 NOT NULL,
    total_amount numeric(10,2) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    category_id integer,
    bank_id uuid,
    created_by uuid,
    employee_id character varying(50),
    expense_number character varying(50),
    item_name character varying(255)
);


--
-- Name: machine_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.machine_payments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    machine_id uuid,
    bank_id uuid,
    payment_date date NOT NULL,
    amount numeric(10,2) DEFAULT 0 NOT NULL,
    remarks text,
    created_at timestamp with time zone DEFAULT now(),
    invoice_id uuid,
    created_by uuid
);


--
-- Name: machines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.machines (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    machine_name character varying(255) NOT NULL,
    machine_number character varying(100) NOT NULL,
    esp_id character varying(100) NOT NULL,
    franchise_id uuid,
    branch_location character varying(255) NOT NULL,
    installation_date date NOT NULL,
    initial_coin_counter integer DEFAULT 0 NOT NULL,
    initial_prize_counter integer DEFAULT 0 NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    notification_type character varying(50) NOT NULL,
    message text NOT NULL,
    related_module character varying(50) NOT NULL,
    user_id uuid,
    status character varying(20) DEFAULT 'unread'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: price_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.price_history (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    franchise_id uuid,
    effective_date date NOT NULL,
    coin_price numeric(10,2),
    doll_price numeric(10,2),
    electricity_cost numeric(10,2),
    vat_percentage numeric(5,2),
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: sales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    machine_id uuid,
    franchise_id uuid,
    sales_date date NOT NULL,
    coin_sales integer NOT NULL,
    sales_amount numeric(10,2) NOT NULL,
    prize_out_quantity integer NOT NULL,
    prize_out_cost numeric(10,2) NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    invoice_number character varying(100),
    payment_status character varying(50) DEFAULT 'Due'::character varying,
    coin_adjustment integer DEFAULT 0,
    prize_adjustment integer DEFAULT 0,
    adjustment_notes text,
    vat_amount numeric(10,2) DEFAULT 0,
    net_sales_amount numeric(10,2) DEFAULT 0,
    clowee_profit numeric(10,2) DEFAULT 0,
    pay_to_clowee numeric(10,2) DEFAULT 0,
    created_by uuid,
    amount_adjustment numeric(10,2) DEFAULT 0,
    electricity_cost numeric(10,2) DEFAULT 0
);


--
-- Name: COLUMN sales.amount_adjustment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sales.amount_adjustment IS 'Small amount adjustment to handle payment differences (e.g., client pays 12400 instead of 12404)';


--
-- Name: stock_out_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_out_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    out_date date NOT NULL,
    machine_id uuid,
    item_id uuid,
    quantity integer NOT NULL,
    remarks text,
    handled_by character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    adjustment_type character varying(50),
    category character varying(100),
    item_name character varying(255),
    unit_price numeric(10,2),
    total_price numeric(10,2)
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(50) DEFAULT 'user'::character varying,
    franchise_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    first_name character varying(255),
    last_name character varying(255),
    username character varying(255),
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'user'::character varying, 'spectator'::character varying, 'super_admin'::character varying])::text[])))
);


--
-- Name: expense_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expense_categories ALTER COLUMN id SET DEFAULT nextval('public.expense_categories_id_seq'::regclass);


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachments (id, franchise_id, file_name, file_url, file_type, file_size, mime_type, uploaded_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, table_name, record_id, action, old_data, new_data, changed_by, changed_at) FROM stdin;
\.


--
-- Data for Name: bank_money_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bank_money_logs (id, bank_id, action_type, amount, transaction_date, remarks, created_by, created_at, updated_at) FROM stdin;
a6c95c17-7bf8-4f61-b550-9d570593709b	841a7673-e6b8-4f07-9d2a-5f14ee159df6	add	341911.00	2025-10-26	27 Oct 2025 \nNCC Bank balance from google sheet - 403322 taka\nClowee ERP balance is - 61411 taka\nBalance: 403322-61411= 341911	\N	2025-10-27 17:38:24.234778	2025-10-27 17:38:24.234778
6744e20f-b5a4-4a1a-a5ef-91dcb77afbb3	8c018b67-1073-45ce-af3b-4c2cf980badc	deduct	41869.00	2025-10-27	27 Oct 2025\nMDB Bank Balance - 16951 taka\nClowee ERP MDB Balance - 58820 \nMDB Balance : 58820-41869= 16951\n	\N	2025-10-27 17:42:31.468719	2025-10-27 17:42:31.468719
8f54ae9d-74dd-4532-8350-5238100bc652	d2fabda9-ee77-4536-a783-67d66406889a	add	202146.25	2025-10-27	27 oct 2025\ncash adjust 202146	\N	2025-10-27 18:22:10.044988	2025-10-27 18:22:10.044988
a590b98d-d0e0-41bd-bc35-ee1573f39eeb	8c018b67-1073-45ce-af3b-4c2cf980badc	add	10080.00	2025-10-28	10080 tk adjusted for MDB Bank	\N	2025-10-28 18:53:05.325521	2025-10-28 18:53:05.325521
a033d81a-1bdc-4908-bc2f-2c7eed449652	d2fabda9-ee77-4536-a783-67d66406889a	deduct	29031.00	2025-10-28	29031 tk adjusted with MDB Bank and bkash	\N	2025-10-28 18:50:59.090768	2025-10-28 18:50:59.090768
1fdd1b31-0a16-4231-bd8a-cea3ae10a6ef	503f5f0e-c268-49b8-adf4-190b10c8cdcc	deduct	174100.38	2025-10-22	27 Oct 2025 \nBaksh balance adjust (-100000)\n\nBkash current balance is : 6087 taka	\N	2025-10-27 17:45:20.261684	2025-10-27 17:45:20.261684
98566973-4155-40b5-b73b-87666edb0952	d2fabda9-ee77-4536-a783-67d66406889a	add	204394.00	2025-11-12	adjustment	\N	2025-11-13 17:15:04.636042	2025-11-13 17:15:04.636042
af8c9905-9d03-4b28-be39-5a24bd103dfd	8c018b67-1073-45ce-af3b-4c2cf980badc	deduct	61321.00	2025-11-13	adjustment	\N	2025-11-13 17:15:41.557823	2025-11-13 17:15:41.557823
\.


--
-- Data for Name: banks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.banks (id, bank_name, account_number, account_holder_name, branch_name, routing_number, is_active, created_at) FROM stdin;
841a7673-e6b8-4f07-9d2a-5f14ee159df6	NCC Bank	00120210025913	I3 Technologies	Gulshan Branch	160261721	t	2025-10-06 14:05:45.735694+06
503f5f0e-c268-49b8-adf4-190b10c8cdcc	Bkash(Personal)	01784457062				t	2025-10-06 14:06:34.446856+06
d2fabda9-ee77-4536-a783-67d66406889a	Cash	Cash				t	2025-10-06 14:05:58.574379+06
8c018b67-1073-45ce-af3b-4c2cf980badc	MDB Bank	00111050008790	I3 TECHNOLOGIES	Gulshan Branch	285261727	t	2025-09-28 00:29:48.525882+06
\.


--
-- Data for Name: expense_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expense_categories (id, category_name, description, is_active, created_at, updated_at) FROM stdin;
9	Local Accessories		t	2025-10-09 16:22:41.259371	2025-10-09 16:22:41.259371
10	Conveyance		t	2025-10-09 16:22:54.93711	2025-10-09 16:22:54.93711
11	Employee Salary		t	2025-10-09 16:23:02.783653	2025-10-09 16:23:02.783653
12	Factory Rent		t	2025-10-09 16:23:16.332898	2025-10-09 16:23:16.332898
15	Server Bill		t	2025-10-09 16:23:56.991701	2025-10-09 16:23:56.991701
16	HR & Admin Cost		t	2025-10-09 16:24:08.702513	2025-10-09 16:24:08.702513
17	Prize Delivery Cost		t	2025-10-09 16:24:21.032248	2025-10-09 16:24:21.032248
18	Prize Purchase		t	2025-10-09 16:24:26.545548	2025-10-09 16:24:26.545548
19	Carrying Cost		t	2025-10-09 16:24:36.802003	2025-10-09 16:24:36.802003
20	Import Accessories		t	2025-10-09 16:24:46.26095	2025-10-09 16:24:46.26095
22	Profit Share(Share Holders)	Amount Deduct from NCC Bank	t	2025-10-12 14:55:48.569558	2025-10-12 14:55:48.569558
23	Office Rent 		t	2025-10-22 18:58:19.433001	2025-10-22 18:58:19.433001
\.


--
-- Data for Name: franchise_agreements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.franchise_agreements (id, franchise_id, effective_date, coin_price, doll_price, franchise_share, clowee_share, electricity_cost, vat_percentage, payment_duration, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: franchises; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.franchises (id, name, coin_price, doll_price, electricity_cost, vat_percentage, franchise_share, clowee_share, payment_duration, maintenance_percentage, security_deposit_type, security_deposit_notes, agreement_copy, trade_nid_copy, created_at, updated_at, payment_bank_id) FROM stdin;
45f8ecfd-161e-476c-80eb-ad4655cdb752	The Dinning Lounge\t	25.00	130.00	337.50	0.00	50.00	50.00	Monthly	\N	\N	\N	\N	{}	2025-10-12 18:37:26.623+06	2025-10-18 00:17:29.631+06	8c018b67-1073-45ce-af3b-4c2cf980badc
3002befd-50db-4aca-964e-9476d0521850	Kolapata Burger	25.00	140.00	0.00	0.00	50.00	50.00	Half Monthly	5.00	\N	\N	http://202.59.208.112:3008/uploads/1761654997165-Kalapata_Aug_Partnership_Agreement_Clowee_pagesetup.pdf	{}	2025-10-16 11:22:28.99+06	2025-10-28 18:36:41.374+06	8c018b67-1073-45ce-af3b-4c2cf980badc
29248edb-d4a3-4a78-9800-a10f60ad3488	PizzaBurg	25.00	130.00	0.00	0.00	60.00	40.00	Monthly	\N	\N	\N	\N	{}	2025-10-12 10:47:58.31+06	2025-10-12 10:47:58.31+06	8c018b67-1073-45ce-af3b-4c2cf980badc
01e5be66-b965-4adb-bc9a-2cfa16954161	Baily Deli\t	25.00	110.00	0.00	5.00	50.00	50.00	Half Monthly	5.00	\N	\N	\N	{}	2025-10-12 18:49:18.478+06	2025-10-13 15:10:00.275+06	8c018b67-1073-45ce-af3b-4c2cf980badc
cd9b585a-fefd-44bf-a97e-7d9b3624126d	The Cafe Rio 	25.00	150.00	250.00	5.00	50.00	50.00	Half Monthly	\N	\N	\N	\N	{}	2025-10-12 11:35:35.788+06	2025-10-13 18:23:23.192+06	8c018b67-1073-45ce-af3b-4c2cf980badc
643bfd3f-24b6-491c-bed7-2d7d17968924	Fino 	25.00	150.00	168.75	0.00	50.00	50.00	Half Monthly	10.00	\N	\N	\N	{}	2025-10-13 16:56:16.927+06	2025-10-16 12:42:13.938+06	8c018b67-1073-45ce-af3b-4c2cf980badc
5ff5d038-a23e-431e-a26c-e98a0bcac2ed	ChefMate Lounge	25.00	150.00	168.75	0.00	50.00	50.00	Half Monthly	10.00	\N	\N	\N	{}	2025-10-13 17:43:46.795+06	2025-11-16 12:49:42.441+06	8c018b67-1073-45ce-af3b-4c2cf980badc
9f092d84-60ed-481b-9466-ec5862e4acf9	MadChef 	25.00	150.00	168.00	0.00	40.00	60.00	Half Monthly	\N	\N	\N	http://202.59.208.112:3008/uploads/1761655068924-MadChef Baily Road Agreement.pdf	{"http://202.59.208.112:3008/uploads/1761655080728-CamScanner 10-28-2025 18.21 (1).jpg","http://202.59.208.112:3008/uploads/1761655080738-CamScanner 10-28-2025 18.21.jpg"}	2025-10-28 18:37:28.704+06	2025-11-16 14:14:07.153+06	841a7673-e6b8-4f07-9d2a-5f14ee159df6
c754765f-279d-4800-88dd-c08b89803b36	Keedlee	25.00	150.00	0.00	0.00	50.00	50.00	Half Month	10.00	\N	\N	\N	{}	2025-10-13 16:53:12.682+06	2025-10-16 13:06:38.88+06	841a7673-e6b8-4f07-9d2a-5f14ee159df6
c41a6043-e460-480b-a569-430c96d00541	Crush Station	25.00	140.00	0.00	0.00	50.00	50.00	Half Monthly	\N	\N	\N	\N	{}	2025-10-13 16:48:50.617+06	2025-10-16 13:11:50.577+06	8c018b67-1073-45ce-af3b-4c2cf980badc
9bbb9704-569c-4293-bbf8-df983d8ed37b	Mr Manik Food 	25.00	140.00	0.00	0.00	50.00	50.00	Monthly	10.00	\N	\N	\N	{}	2025-10-13 17:45:50.089+06	2025-10-16 16:34:20.482+06	8c018b67-1073-45ce-af3b-4c2cf980badc
d2f93e6d-44a3-4fbf-9a2b-e74661e0ea7a	Food Rail	25.00	150.00	168.75	0.00	50.00	50.00	Half Monthly	10.00	\N	\N	\N	{}	2025-10-13 17:31:57.469+06	2025-10-16 16:34:36.283+06	8c018b67-1073-45ce-af3b-4c2cf980badc
c9168bd5-0b15-49dc-9a35-cc5b52535600	Shang High	30.00	150.00	0.00	0.00	40.00	60.00	Half Monthly	\N	\N	\N	\N	{}	2025-10-13 16:54:31.972+06	2025-10-16 16:34:44.315+06	841a7673-e6b8-4f07-9d2a-5f14ee159df6
ab390752-da90-4d3f-9a9d-1f2f4b2f5eae	Fuoco	25.00	130.00	78.25	0.00	50.00	50.00	Half Monthly	5.00	\N	\N	\N	{}	2025-10-13 16:52:19.237+06	2025-10-16 16:34:53.581+06	8c018b67-1073-45ce-af3b-4c2cf980badc
\.


--
-- Data for Name: inventory_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_transactions (id, item_id, transaction_type, quantity, transaction_date, related_invoice, notes, created_at) FROM stdin;
\.


--
-- Data for Name: ledger_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ledger_entries (id, entry_date, type, debit, credit, balance, description, reference_id, created_at) FROM stdin;
\.


--
-- Data for Name: machine_counters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.machine_counters (id, machine_id, reading_date, coin_counter, prize_counter, notes, created_at, created_by) FROM stdin;
4747d147-e0ee-40d3-9924-e65918e3294c	3531f437-b29d-4f5c-8891-2463ae8e70b5	2025-10-31	40014	3117		2025-11-02 12:05:30.855001+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
f348b1d2-0c23-472d-8b5f-7b27731a2f1e	74077ddb-cbfc-46de-a0b6-1e2d1b68e4aa	2025-10-31	21651	1538		2025-11-02 12:09:08.565975+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
99fc6762-7f9f-422d-807b-fa9d19522004	2fd45c00-2dce-471f-a4d8-f5ede2d712c4	2025-09-30	35353	3150		2025-10-12 10:51:51.819367+06	\N
05b876e1-4ac1-4564-ac4b-a5304a96a9de	6f603dc0-90ac-4d7d-ac3a-ee7bfe9557c8	2025-09-30	4748	2206		2025-10-12 11:10:22.022137+06	\N
d5625581-c3c6-442e-98c7-aef5b1c7b588	6ee6ed8e-bff1-43d0-a29b-1764668b2b29	2025-09-30	49198	2935		2025-10-12 11:16:41.167682+06	\N
26b73420-e01f-4f70-abc3-47d79aa72f45	b5327e30-7b83-4fda-99aa-99a107bbcca9	2025-09-30	53791	3491		2025-10-12 11:42:32.931121+06	\N
96b5415d-590d-44bc-9179-252e4a2123eb	3869bce6-8e5d-4e64-9197-24400000d168	2025-09-30	13352	6894		2025-10-12 18:52:32.023729+06	\N
78ea3608-70a2-4fad-9b2e-581f7dcc7704	74077ddb-cbfc-46de-a0b6-1e2d1b68e4aa	2025-09-30	20824	1423		2025-10-14 10:49:37.34701+06	\N
cdf8e3e4-7880-48fa-b885-affd650d0b3f	29e89cc6-04f5-475d-8dd7-c2efe05d4c55	2025-09-30	52434	3667		2025-10-14 10:59:08.064458+06	\N
976cd2d7-fff5-4429-ba9f-2e9bae9af9ae	4f9ad276-ec83-423b-bb6a-3431e5b5d74f	2025-09-30	14410	42493		2025-10-14 11:01:25.419586+06	\N
27055443-8d1a-41bb-9ded-f37ad958b136	ee68bac1-c967-4b3e-be4c-53aeba1f1249	2025-09-30	16109	2189		2025-10-14 11:02:14.921282+06	\N
82659336-a65b-4797-ad28-f4a1c01a4242	b873dc83-b55c-4fdc-98b9-7dc25e9d5a10	2025-09-30	25842	1619		2025-10-14 11:02:46.524782+06	\N
88305ebe-56c3-436e-8fda-8c5d44314d29	aa75ca99-9bf5-4156-af35-4467c84f44fd	2025-09-30	20126	1253		2025-10-14 11:12:57.311241+06	\N
c956e914-bdc5-42a0-b925-d0758301961d	8cb8bd6f-be4d-4964-8e10-eddd392cff87	2025-09-30	36582	2956		2025-10-14 11:13:32.775364+06	\N
a96efe7b-570e-4eaf-a5a8-e5d9829657b3	ae0f877f-a5b4-4955-a295-317855b3ff27	2025-09-30	13070	1406		2025-10-14 11:14:10.212464+06	\N
08574b1d-c896-4f81-9b44-07bdb407b7f6	277b890a-f8fe-4cb2-a106-066731d848e3	2025-09-30	9694	1326		2025-10-14 11:38:21.19013+06	\N
b54938dc-6981-41ef-b270-34cbbfa7dcda	bf03337a-93fd-45a5-84c1-79fb21d59745	2025-09-30	424	16		2025-10-14 11:43:02.04616+06	\N
0455025f-9857-4945-a33a-d2f4a97debb1	dfbbdc7f-e2de-4351-be66-4a05ee1aa6ed	2025-09-30	6412	1939		2025-10-14 11:50:34.183366+06	\N
987b7f85-9489-4f83-a8b2-a170dce45864	feb921c1-425c-4a8a-8748-f7d958a7d3e0	2025-09-30	1837	806		2025-10-14 11:53:26.454391+06	\N
796aa512-8a07-4465-966a-0c71be9825a3	b957c84b-8cc1-4ee9-a24c-a80565676721	2025-09-30	16962	997		2025-10-14 11:54:24.863799+06	\N
07c66665-11c7-4da4-9c36-9b1e4a879cda	6d29d8b3-9777-4a01-8431-53acbcad9363	2025-09-30	6885	1788		2025-10-14 12:04:06.805592+06	\N
fcb5966d-81ef-4833-8f0b-27524963159c	d3e8eb14-b460-4f82-b334-790165c2a922	2025-09-30	6160	2114		2025-10-14 12:04:35.476399+06	\N
20737c2d-6235-4e2c-908c-8e87f2c7a55a	1885a455-019b-43d3-80e6-7a4fcc1e1232	2025-09-30	10236	24648		2025-10-14 12:26:43.351096+06	\N
5c48977c-5e1d-4383-8bef-19adf486cdf5	ee68bac1-c967-4b3e-be4c-53aeba1f1249	2025-10-15	16318	2199		2025-10-16 10:32:16.231479+06	b61a9829-5b43-41bc-b09a-3d74a0e05767
a3980e05-b30e-486c-8f9e-16a76e283221	07490f7a-5244-4e67-bcc0-4fd1df88ed92	2025-09-30	18009	1053		2025-10-16 11:27:30.150351+06	b61a9829-5b43-41bc-b09a-3d74a0e05767
d64bb0c1-e420-4d1e-9422-20b76ba01cbf	bf03337a-93fd-45a5-84c1-79fb21d59745	2025-10-15	698	35		2025-10-16 11:31:52.260525+06	b61a9829-5b43-41bc-b09a-3d74a0e05767
fb526ac8-0481-4526-b275-beffaffc381c	b5327e30-7b83-4fda-99aa-99a107bbcca9	2025-10-15	56547	3635		2025-10-16 12:08:58.231878+06	b61a9829-5b43-41bc-b09a-3d74a0e05767
2c98c10e-a154-4254-ba21-a091e2528a2f	dfbbdc7f-e2de-4351-be66-4a05ee1aa6ed	2025-10-15	6734	1949		2025-10-16 12:38:34.289218+06	b61a9829-5b43-41bc-b09a-3d74a0e05767
b4313bef-3ac5-4e01-8007-3fbe92459961	3869bce6-8e5d-4e64-9197-24400000d168	2025-10-15	15115	6938		2025-10-16 13:34:21.914608+06	b61a9829-5b43-41bc-b09a-3d74a0e05767
30efc8f4-eb5c-4fa6-b390-5f493b0ce8a5	07490f7a-5244-4e67-bcc0-4fd1df88ed92	2025-10-15	18292	1058		2025-10-16 13:54:44.695707+06	b61a9829-5b43-41bc-b09a-3d74a0e05767
5669d5a6-b81d-4f54-97aa-d1a9bc2ec36f	29e89cc6-04f5-475d-8dd7-c2efe05d4c55	2025-10-15	52749	3689		2025-10-16 13:56:42.010521+06	b61a9829-5b43-41bc-b09a-3d74a0e05767
000ce0b9-428c-4794-bcd9-97f9fcbd152b	277b890a-f8fe-4cb2-a106-066731d848e3	2025-10-15	9837	1337		2025-10-16 15:33:27.861355+06	b61a9829-5b43-41bc-b09a-3d74a0e05767
11e392fe-c2d3-473e-9556-58fa9374b706	b873dc83-b55c-4fdc-98b9-7dc25e9d5a10	2025-10-15	26220	1644		2025-10-16 15:41:20.320053+06	b61a9829-5b43-41bc-b09a-3d74a0e05767
08dea6f2-ed18-4688-b3a5-fb488013cd84	d3e8eb14-b460-4f82-b334-790165c2a922	2025-10-15	6232	2115		2025-10-16 15:43:34.950333+06	b61a9829-5b43-41bc-b09a-3d74a0e05767
dd5b2507-b5df-437e-a66a-209580bd05fd	4c5dda16-9682-4bba-aed0-c38e82ec5356	2025-10-15	469	38		2025-10-16 15:49:40.539576+06	b61a9829-5b43-41bc-b09a-3d74a0e05767
9171d100-621e-4898-80e4-1c7e1759869d	74077ddb-cbfc-46de-a0b6-1e2d1b68e4aa	2025-10-15	21340	1508		2025-10-16 16:55:46.046878+06	b61a9829-5b43-41bc-b09a-3d74a0e05767
5e56711a-4ee1-44d1-a7cf-fbb7dc7695c8	72cbe2e1-4a91-425e-8a53-71533ffbdb0e	2025-10-15	3097	959		2025-10-19 11:53:04.974057+06	b61a9829-5b43-41bc-b09a-3d74a0e05767
6b53703a-c9f4-437a-bef5-14076bc9b656	feb921c1-425c-4a8a-8748-f7d958a7d3e0	2025-10-15	2509	830		2025-10-19 12:08:56.057547+06	b61a9829-5b43-41bc-b09a-3d74a0e05767
ad3d9615-3d72-4df5-9b51-e4eb1445f5a6	b873dc83-b55c-4fdc-98b9-7dc25e9d5a10	2025-10-31	26481	1657		2025-11-02 13:02:19.310669+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
c90d7a6a-33be-4604-b43e-fb49e92e5484	b957c84b-8cc1-4ee9-a24c-a80565676721	2025-10-15	17380	1006		2025-10-19 12:29:24.64463+06	b61a9829-5b43-41bc-b09a-3d74a0e05767
f83f5c22-73fb-4530-85c5-ace922ffd236	6d29d8b3-9777-4a01-8431-53acbcad9363	2025-10-15	7135	1795		2025-10-19 16:00:09.544567+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
aae8a08b-a40b-4de1-95eb-4018b83357e5	72cbe2e1-4a91-425e-8a53-71533ffbdb0e	2025-09-30	2824	940		2025-10-20 16:35:36.749509+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
7e1b0ddb-dfbf-433a-a716-bec90b33e51d	4f9ad276-ec83-423b-bb6a-3431e5b5d74f	2025-10-15	14813	42507		2025-10-20 16:58:32.036836+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
1ca9927e-3919-49b7-8779-50586c9495a2	3531f437-b29d-4f5c-8891-2463ae8e70b5	2025-09-30	37348	3043		2025-10-21 15:48:51.916596+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
9c7f812d-1168-471f-8181-d91c2e63ee8c	3531f437-b29d-4f5c-8891-2463ae8e70b5	2025-10-15	39162	3095		2025-10-21 15:49:30.143091+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
1515a0c1-8969-494e-b5d7-f264cb6fb950	277b890a-f8fe-4cb2-a106-066731d848e3	2025-10-31	10010	1343		2025-11-02 10:31:38.195465+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
5e3da6df-5988-41a1-bdc4-7e9f66942e7f	b5327e30-7b83-4fda-99aa-99a107bbcca9	2025-10-31	59379	3802		2025-11-02 10:36:59.970695+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
58347684-1ced-4484-b8c0-84c5d4188bc9	29e89cc6-04f5-475d-8dd7-c2efe05d4c55	2025-10-31	53139	3717		2025-11-02 13:04:10.270748+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
b00aa8c7-931c-4829-a68a-74e4cbc506ff	4f9ad276-ec83-423b-bb6a-3431e5b5d74f	2025-10-31	15190	42521		2025-11-02 13:05:03.407352+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
f2d80fd9-2ee1-4825-afb5-7f3fe72583bd	bf03337a-93fd-45a5-84c1-79fb21d59745	2025-10-31	1082	67		2025-11-02 13:11:07.192536+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
75e41f0d-c402-4fad-8069-d71c07e0775a	dfbbdc7f-e2de-4351-be66-4a05ee1aa6ed	2025-10-31	7112	1957		2025-11-02 13:21:05.780207+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
7b438d12-29e8-4e60-87b0-1bfa26bb1618	1885a455-019b-43d3-80e6-7a4fcc1e1232	2025-10-31	10592	24671		2025-11-02 13:26:40.78459+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
c595b683-54ed-4e8a-8d3b-9d0a6d902d68	4c5dda16-9682-4bba-aed0-c38e82ec5356	2025-10-31	669	49		2025-11-02 13:32:08.251351+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
ff1bed34-cf04-4c5f-9743-25f89bfc9283	feb921c1-425c-4a8a-8748-f7d958a7d3e0	2025-10-31	2982	836		2025-11-02 14:17:18.994094+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
2889a7f7-3654-47e8-b1ef-522b93d60ba0	b957c84b-8cc1-4ee9-a24c-a80565676721	2025-10-31	17904	1019		2025-11-02 14:17:48.555116+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
c026be0b-84ab-46fb-912e-f11ce27b45be	b084d7e5-1c69-4d42-9650-3b2ee45443d3	2025-09-30	26727	1973		2025-11-02 15:57:46.297186+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
ca8d7dc9-c1d4-4922-8416-1e8459de7b53	b084d7e5-1c69-4d42-9650-3b2ee45443d3	2025-10-30	27286	2000		2025-11-02 15:58:17.598436+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
d003bd35-5af3-40f0-a2a6-967de47fde01	ae0f877f-a5b4-4955-a295-317855b3ff27	2025-10-31	13341	1437		2025-11-02 16:08:10.518913+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
32505381-3e2f-4012-83b1-f0df3b62e0bc	aa75ca99-9bf5-4156-af35-4467c84f44fd	2025-10-31	20747	1290		2025-11-02 16:08:41.513376+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
f429a73a-7cc6-4bc9-813f-77ed55d5a393	8cb8bd6f-be4d-4964-8e10-eddd392cff87	2025-10-31	37451	3021		2025-11-02 16:09:46.760699+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
f98f8b94-f2a9-482c-a2a1-c34bf1fcff3c	6d29d8b3-9777-4a01-8431-53acbcad9363	2025-10-31	7583	1811		2025-11-02 16:39:29.73829+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
69bc6c68-33ff-4c05-9cba-b58ac83836a2	3869bce6-8e5d-4e64-9197-24400000d168	2025-10-31	17003	7033		2025-11-02 16:53:59.83479+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
d223d534-7b82-4e37-bc01-d424bb63859b	07490f7a-5244-4e67-bcc0-4fd1df88ed92	2025-10-31	18511	1065		2025-11-02 18:18:25.293765+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
5f622409-0a55-4a01-a69f-3ca5b3077671	ee68bac1-c967-4b3e-be4c-53aeba1f1249	2025-10-31	16735	2222		2025-11-03 18:13:10.713061+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
2cb02e2b-0301-42e9-ad40-fbb34bcd2058	2fd45c00-2dce-471f-a4d8-f5ede2d712c4	2025-10-31	36509	3222		2025-11-03 18:55:36.460883+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
84dff9f2-d63e-4b24-8560-e4d90903911e	6f603dc0-90ac-4d7d-ac3a-ee7bfe9557c8	2025-10-31	5654	2241		2025-11-03 18:56:09.437807+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
c072f8db-cb07-4063-9276-5672463e1e1f	6ee6ed8e-bff1-43d0-a29b-1764668b2b29	2025-10-31	51297	3028		2025-11-03 19:03:11.220974+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
89f2d3b9-85e9-46cd-a43b-4b0f6426b26e	72cbe2e1-4a91-425e-8a53-71533ffbdb0e	2025-10-31	3532	976		2025-11-04 11:07:00.99204+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
e58e76e3-23b2-40de-a19b-425142d6275a	d3e8eb14-b460-4f82-b334-790165c2a922	2025-10-31	6355	2118		2025-11-04 11:14:08.423622+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
f2f4aa1d-a18d-4d42-adb2-7541f712ba61	1885a455-019b-43d3-80e6-7a4fcc1e1232	2025-11-12	10747	24683		2025-11-12 16:06:41.131549+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
36eb485c-9196-4a88-9b8c-d03f4a7af007	4f9ad276-ec83-423b-bb6a-3431e5b5d74f	2025-11-15	15502	42529		2025-11-16 10:42:36.187402+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
4dbc8c2c-b022-4715-976f-e28a7e15e05d	ee68bac1-c967-4b3e-be4c-53aeba1f1249	2025-11-15	17016	2233		2025-11-16 10:37:59.716888+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
c80ed5a8-c033-4ecc-9c19-fe663318ac5b	bf03337a-93fd-45a5-84c1-79fb21d59745	2025-11-15	1446	97		2025-11-16 10:54:01.786173+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
73c6437f-d00e-4b11-a4a9-95b51294d674	dfbbdc7f-e2de-4351-be66-4a05ee1aa6ed	2025-11-15	7447	1964		2025-11-16 11:31:06.672253+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
98ca76b9-752d-4c8a-9f10-b8de1afedbdb	d5a1699b-e816-4560-b055-433d69949c23	2025-11-15	825	628		2025-11-16 11:49:04.55539+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
84e19dbb-78af-4f97-a2e9-bc4e0e6228cb	277b890a-f8fe-4cb2-a106-066731d848e3	2025-11-15	10217	1349		2025-11-16 12:08:33.611881+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
d2019fb2-3ba5-47ab-807a-9fa274ab4a17	3869bce6-8e5d-4e64-9197-24400000d168	2025-11-15	18440	7088		2025-11-16 12:28:35.973423+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
0da77ff7-8374-4554-9976-e6227a76d30b	3531f437-b29d-4f5c-8891-2463ae8e70b5	2025-11-15	40914	3139		2025-11-16 13:12:46.354972+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
d2117aaf-8bf4-4385-a85f-79536b66ccf1	74077ddb-cbfc-46de-a0b6-1e2d1b68e4aa	2025-11-15	22079	1606		2025-11-16 13:12:07.71473+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
b04f00bf-2dc6-4ddb-9f63-b146401e5d40	07490f7a-5244-4e67-bcc0-4fd1df88ed92	2025-11-15	18888	1071		2025-11-16 14:31:11.471099+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
900b813b-8130-4507-adf4-101492ddd1e6	4c5dda16-9682-4bba-aed0-c38e82ec5356	2025-11-15	1013	61		2025-11-16 14:36:00.079363+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
0550195e-d072-4d11-8f6a-68fa0ce688f8	b5327e30-7b83-4fda-99aa-99a107bbcca9	2025-11-15	61623	3948		2025-11-16 18:23:06.012245+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
71ea6d80-ff6d-4c03-ab18-136bd46fb996	b873dc83-b55c-4fdc-98b9-7dc25e9d5a10	2025-11-15	26661	1669		2025-11-16 18:53:13.318784+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
1b0fb652-e907-445c-8eb8-bb7f4cf03bd1	29e89cc6-04f5-475d-8dd7-c2efe05d4c55	2025-11-15	53334	3731		2025-11-17 11:27:22.837673+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
977340cd-8936-4719-a1ab-ad01fe7fb20f	feb921c1-425c-4a8a-8748-f7d958a7d3e0	2025-11-15	3339	849		2025-11-17 11:52:54.932381+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
64c63cd9-3f7d-4fd3-be05-8bfca61d6a68	b957c84b-8cc1-4ee9-a24c-a80565676721	2025-11-15	18610	1044		2025-11-17 11:53:45.522016+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
f771f962-9751-4eae-a4b7-4e2bbce50811	6d29d8b3-9777-4a01-8431-53acbcad9363	2025-11-15	7844	1821		2025-11-17 16:21:16.193186+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
9383b9a9-2666-4dc1-8006-8be920343815	72cbe2e1-4a91-425e-8a53-71533ffbdb0e	2025-11-15	3914	991		2025-11-19 13:43:32.238223+06	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
\.


--
-- Data for Name: machine_expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.machine_expenses (id, machine_id, expense_date, expense_details, quantity, item_price, total_amount, created_at, category_id, bank_id, created_by, employee_id, expense_number, item_name) FROM stdin;
10574f5c-fdc4-406d-a39d-7ee05e2bebfa	\N	2025-09-01	Salary- Office Boy- Rezaul Karim - Sep 2025	1	3000.00	3000.00	2025-10-25 00:16:07.858391+06	11	d2fabda9-ee77-4536-a783-67d66406889a	975b7b9b-f608-45c0-861d-d91695ec79e9	10021	clw-ex-0039	\N
27ecfc02-2e71-4ff1-a8db-02c78659bd63	4f9ad276-ec83-423b-bb6a-3431e5b5d74f	2025-10-26	Expense	50	100.00	5000.00	2025-10-26 17:05:53.527801+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0040	\N
e858d33a-5f96-4e5d-8a2b-5a409991fb06	\N	2025-09-30	Expense	1	13998.00	13998.00	2025-10-22 13:50:36.380832+06	10	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0002	\N
b596455a-2404-4d59-bfdb-517ef10d6836	\N	2025-09-30	Utility bills (3:1)	1	4323.00	4323.00	2025-10-22 19:00:14.648728+06	16	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0024	\N
68d12eea-373b-4369-b455-8fe2ae0513ea	2fd45c00-2dce-471f-a4d8-f5ede2d712c4	2025-10-27	Expense	100	100.00	10000.00	2025-10-27 17:52:32.322718+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0042	\N
66c2c0a3-f52b-4f28-8768-7b91211e5dfb	3869bce6-8e5d-4e64-9197-24400000d168	2025-10-06	Expense	100	100.00	10000.00	2025-10-27 18:00:17.969815+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0044	\N
b50d83db-b930-455d-ae76-e33167799f19	b5327e30-7b83-4fda-99aa-99a107bbcca9	2025-10-27	Expense	100	100.00	10000.00	2025-10-27 18:00:56.728583+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0046	\N
4c2bd39d-9433-4a90-aa2f-7a48a6e45906	\N	2025-10-27	Rezaul vai Conveyance	1	4180.00	4180.00	2025-10-27 18:08:53.379091+06	10	d2fabda9-ee77-4536-a783-67d66406889a	975b7b9b-f608-45c0-861d-d91695ec79e9	\N	clw-ex-0048	\N
b676e7ce-15c7-48ca-a1d7-c3c06adec0ba	feb921c1-425c-4a8a-8748-f7d958a7d3e0	2025-10-28	Expense	50	100.00	5000.00	2025-10-28 17:49:49.957406+06	18	8c018b67-1073-45ce-af3b-4c2cf980badc	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0050	\N
bde9ca0b-c3c4-4de1-9e10-163af10fd6d9	6f603dc0-90ac-4d7d-ac3a-ee7bfe9557c8	2025-11-03	Expense	100	100.00	10000.00	2025-11-03 17:55:20.141807+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0052	\N
11eaa642-5389-4272-8ebd-872638ac3525	74077ddb-cbfc-46de-a0b6-1e2d1b68e4aa	2025-10-27	Office to Mohmmadpur cafe Rio Bill Collection Oct 1-15	1	100.00	100.00	2025-11-04 12:31:37.771885+06	10	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0054	\N
9e152744-4892-4318-81f9-8cd0235d483f	\N	2025-10-28	Visiting MadChef Brunch – Bailey Road & Banani +Lunch	1	450.00	450.00	2025-11-04 12:33:04.130844+06	10	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0056	\N
8160fff6-8254-455c-a9c3-10f8c77447d2	d5a1699b-e816-4560-b055-433d69949c23	2025-10-30	MadChef Baily Road for clowee New Machine Setup	1	300.00	300.00	2025-11-04 12:38:10.187616+06	10	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0058	\N
b99a4a45-da3b-4db7-bf4a-3bcecc3fd875	\N	2025-10-01	Expense	1	48000.00	48000.00	2025-11-04 12:39:16.990087+06	11	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	10006	clw-ex-0060	\N
af712b4f-f963-45a3-8ef5-6be95ab86eb4	\N	2025-10-01	Expense	1	18000.00	18000.00	2025-11-04 12:41:03.735265+06	11	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	10011	clw-ex-0062	\N
1b17734a-4613-4330-9cbb-a5940fb6d953	\N	2025-10-01	Expense	1	5500.00	5500.00	2025-11-04 12:41:49.894814+06	12	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0064	\N
0c4a9979-4c09-4ce6-a744-a9410fd27018	\N	2025-10-01	Expense	1	5000.00	5000.00	2025-11-04 12:42:54.695109+06	15	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0066	\N
893f7cf9-1297-426c-9075-ff17584cc44b	277b890a-f8fe-4cb2-a106-066731d848e3	2025-11-01	Fuoco Uttara press button fix - Rezaul	1	400.00	400.00	2025-11-04 12:51:13.214748+06	10	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0068	\N
fea17699-6315-4b60-98c9-d6cf2fa21859	4c5dda16-9682-4bba-aed0-c38e82ec5356	2025-11-02	ChefMate Lounge Bill Collection	1	100.00	100.00	2025-11-04 12:54:48.216921+06	10	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0070	\N
8a2ef2f3-c2d0-4696-9862-b2a7407a1b4d	2fd45c00-2dce-471f-a4d8-f5ede2d712c4	2025-11-03	Office to Pizzaburg Gulshan Machine Crane Problem	1	300.00	300.00	2025-11-04 12:55:40.788593+06	10	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0072	\N
b29b1762-6f88-4e74-84f9-ce1958fb3384	07490f7a-5244-4e67-bcc0-4fd1df88ed92	2025-11-04	Expense	50	100.00	5000.00	2025-11-04 17:04:07.051036+06	18	8c018b67-1073-45ce-af3b-4c2cf980badc	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0074	\N
5b552f75-0d05-449e-b930-bc0d2d05be9b	3869bce6-8e5d-4e64-9197-24400000d168	2025-11-11	Expense	100	100.00	10000.00	2025-11-11 17:39:39.941784+06	18	8c018b67-1073-45ce-af3b-4c2cf980badc	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0078	\N
98124b24-91b6-4fb5-80ff-8309c07a5dd6	33a1a534-951a-4f86-a832-188fa5117b57	2025-11-09	Expense	100	100.00	10000.00	2025-11-09 19:30:52.886317+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0077	\N
f207a882-b6c4-429d-8fd9-4a1a9819de11	1885a455-019b-43d3-80e6-7a4fcc1e1232	2025-11-08	Mr Manik Food To Office Machine 	1	2550.00	2550.00	2025-11-13 11:13:01.418329+06	19	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0080	\N
2f5ca1af-fa33-4a8d-a557-0c0481af3a5e	33a1a534-951a-4f86-a832-188fa5117b57	2025-11-09	Office to MadChef Dhanmondi Outlet Visit	1	100.00	100.00	2025-11-13 11:14:27.470351+06	10	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0082	\N
1785d946-f1e6-41cd-9d9e-37f36f17d8e3	b5327e30-7b83-4fda-99aa-99a107bbcca9	2025-11-13	Cafe Rio Mipur bill collection	1	250.00	250.00	2025-11-13 11:15:09.564886+06	10	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0084	\N
396e59cb-91bd-433e-90d2-f56ea4201823	3531f437-b29d-4f5c-8891-2463ae8e70b5	2025-10-27	sticker change	1	1675.00	1675.00	2025-11-13 18:06:46.396801+06	9	d2fabda9-ee77-4536-a783-67d66406889a	12ad4585-93b8-4559-b76b-9b4ff2dabc9a	\N	clw-ex-0086	Sticker Print(Cafe rio Uttara)
4b9ff4a9-7437-45ff-8b38-6f88cbc1b22e	b5327e30-7b83-4fda-99aa-99a107bbcca9	2025-10-11	clowee sticker print - cafe rio mirpur	1	1675.00	1675.00	2025-10-27 18:08:16.613461+06	9	d2fabda9-ee77-4536-a783-67d66406889a	975b7b9b-f608-45c0-861d-d91695ec79e9	\N	clw-ex-0047	Clowee sticker print(cafe rio mirpur)
f8a3deaa-f63f-4439-976b-a17d18c6eea6	4c5dda16-9682-4bba-aed0-c38e82ec5356	2025-11-17	Expense	50	100.00	5000.00	2025-11-17 17:39:11.57226+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0088	\N
40ed370e-ac70-4169-8fa6-c0ebadb40111	74077ddb-cbfc-46de-a0b6-1e2d1b68e4aa	2025-11-19	Expense	1	80.00	80.00	2025-11-19 18:15:57.567601+06	10	d2fabda9-ee77-4536-a783-67d66406889a	b61a9829-5b43-41bc-b09a-3d74a0e05767	\N	clw-ex-0090	\N
8bc1ac12-a66f-423d-b44e-2be1b7de9821	\N	2025-11-20	Expense	2	25.00	50.00	2025-11-20 14:00:14.879925+06	9	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0091	Blade
48830322-0f53-4785-bb32-730ed861d62d	\N	2025-11-20	Expense	1	300.00	300.00	2025-11-20 14:00:32.603469+06	17	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0092	\N
3489205b-29b6-4554-aad1-e5ee35bfbeca	6ee6ed8e-bff1-43d0-a29b-1764668b2b29	2025-11-22	Expense	100	100.00	10000.00	2025-11-22 20:56:07.908925+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0093	\N
59ff60c8-d1d4-4a46-8060-5c20525b6721	\N	2025-11-22	Expense	50	100.00	5000.00	2025-11-22 20:56:24.482735+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0094	\N
14e08c8d-e45b-4e0a-9d4c-22014d4d84ba	d5a1699b-e816-4560-b055-433d69949c23	2025-11-23	Expense	100	100.00	10000.00	2025-11-23 18:15:58.744747+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0095	\N
ee0f636a-7659-4a89-bdb7-d944e8dae586	b5327e30-7b83-4fda-99aa-99a107bbcca9	2025-11-23	Expense	100	100.00	10000.00	2025-11-23 18:17:22.80337+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0096	\N
e815d5a5-b2da-467a-8e82-37421ba4cc1e	\N	2025-09-01	Server Bill Sep 2025	1	5000.00	5000.00	2025-10-22 18:59:26.499603+06	15	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0023	\N
27095973-7fca-4e89-9afb-2325176304a1	2fd45c00-2dce-471f-a4d8-f5ede2d712c4	2025-09-02	Expense	100	100.00	10000.00	2025-10-22 13:54:22.795241+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0003	\N
8069278d-478d-47ce-83a5-fd54825cf7b2	b5327e30-7b83-4fda-99aa-99a107bbcca9	2025-09-04	Expense	400	100.00	40000.00	2025-10-22 13:55:09.558962+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0004	\N
d8f790bd-9f38-46ee-95a1-f5c50dd009b6	6ee6ed8e-bff1-43d0-a29b-1764668b2b29	2025-09-10	Expense	100	100.00	10000.00	2025-10-22 13:55:52.213933+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0005	\N
707ccb11-6d73-46c6-80f1-0a8b723fae3a	aa75ca99-9bf5-4156-af35-4467c84f44fd	2025-09-10	Expense	100	100.00	10000.00	2025-10-22 13:56:30.215829+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0006	\N
38d2b8ba-5468-49fb-93a5-3771d86a19e8	3869bce6-8e5d-4e64-9197-24400000d168	2025-09-11	Expense	100	100.00	10000.00	2025-10-22 13:57:02.941928+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0007	\N
c54698e8-f4c7-4f7b-813e-ce5d3eb3bdf2	6f603dc0-90ac-4d7d-ac3a-ee7bfe9557c8	2025-09-18	Expense	100	100.00	10000.00	2025-10-22 13:58:18.389666+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0008	\N
3e40d61c-d605-4c2d-b440-a6880be61003	07490f7a-5244-4e67-bcc0-4fd1df88ed92	2025-09-18	Expense	50	100.00	5000.00	2025-10-22 13:58:53.595111+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0009	\N
97288574-97a8-48a3-96ec-750e787db30a	3531f437-b29d-4f5c-8891-2463ae8e70b5	2025-09-21	Expense	100	100.00	10000.00	2025-10-22 14:00:17.996882+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0011	\N
0e39908a-40c5-4b9e-a77d-b9cd2b922621	\N	2025-09-12	Expense	100	100.00	10000.00	2025-10-22 14:04:07.777908+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0015	\N
58604c04-a1da-4406-82a2-683b23e69327	29e89cc6-04f5-475d-8dd7-c2efe05d4c55	2025-09-25	Expense	50	100.00	5000.00	2025-10-22 14:01:05.615881+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0012	\N
70c37b44-097c-4d28-8629-72eae40effa6	b873dc83-b55c-4fdc-98b9-7dc25e9d5a10	2025-09-25	Expense	50	100.00	5000.00	2025-10-22 14:01:47.636599+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0013	\N
715bccd3-bbd6-4dcc-98a2-6c499fb8116f	8cb8bd6f-be4d-4964-8e10-eddd392cff87	2025-09-21	Expense	100	100.00	10000.00	2025-10-22 13:59:28.410407+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0010	\N
f27fb3bb-8f72-48c6-81d3-64aab353da10	b084d7e5-1c69-4d42-9650-3b2ee45443d3	2025-09-25	Expense	100	100.00	10000.00	2025-10-22 14:02:20.590808+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0014	\N
d81b14a5-63ea-416d-a03a-d3f5d5ce3ffb	29e89cc6-04f5-475d-8dd7-c2efe05d4c55	2025-09-11	Expense	50	100.00	5000.00	2025-10-22 14:16:08.1107+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0016	\N
d2de375b-adea-43ce-9137-d71362f370bc	\N	2025-09-01	Factory Rent  Sep 2025	1	5500.00	5500.00	2025-10-22 18:56:32.250538+06	12	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0021	\N
d3cab802-2630-4c59-822d-2a4b8963dcfa	\N	2025-09-30	Office Rent  Sep 2025	1	5000.00	5000.00	2025-10-22 18:58:59.583283+06	23	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0022	\N
351233d5-3496-4b11-bbac-2671309b5fd7	\N	2025-10-12	Stedfast Bill	1	2540.00	2540.00	2025-10-23 11:11:01.785317+06	17	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0026	\N
a68d109b-1eb6-42f5-be9f-53cd302a5cba	\N	2025-10-12	stories cafe machine crrying cost	1	1100.00	1100.00	2025-10-23 11:11:53.50448+06	19	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0028	\N
e79139e4-1a08-4d9d-8737-b625374f6ed0	\N	2025-10-12	Office to The Stories Cafe Mirpur	1	200.00	200.00	2025-10-23 11:12:16.794218+06	10	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0029	\N
d709c20e-9e92-4dc5-8b6f-0a50b1b366c1	2fd45c00-2dce-471f-a4d8-f5ede2d712c4	2025-10-05	Expense	100	100.00	10000.00	2025-10-23 11:24:40.4038+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0030	\N
3285125f-8a72-4c6f-ac4f-defe0e459612	feb921c1-425c-4a8a-8748-f7d958a7d3e0	2025-10-05	Expense	50	100.00	5000.00	2025-10-23 11:25:46.696461+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0031	\N
166fa795-4a9f-4b85-aca8-59aab2aaf954	277b890a-f8fe-4cb2-a106-066731d848e3	2025-10-07	Expense	50	100.00	5000.00	2025-10-23 11:26:47.350307+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0032	\N
8a33a37f-556e-4c7f-89da-555ed04d0b94	72cbe2e1-4a91-425e-8a53-71533ffbdb0e	2025-10-07	Expense	50	100.00	5000.00	2025-10-23 11:27:50.385312+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0034	\N
f4aa37ec-56c8-4b4f-b096-931bd9e813d6	b5327e30-7b83-4fda-99aa-99a107bbcca9	2025-10-09	Expense	100	100.00	10000.00	2025-10-23 11:29:23.50293+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0036	\N
bd96ad27-2781-4821-ba6f-8dc27c2561e2	74077ddb-cbfc-46de-a0b6-1e2d1b68e4aa	2025-10-09	Expense	100	100.00	10000.00	2025-10-23 11:29:48.118873+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0037	\N
2de1fccd-d996-4283-8446-853c41e7d38e	6ee6ed8e-bff1-43d0-a29b-1764668b2b29	2025-10-12	Expense	100	100.00	10000.00	2025-10-23 11:30:36.079598+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0038	\N
3ca8acbd-2632-4482-a562-2fc33b96ccee	8cb8bd6f-be4d-4964-8e10-eddd392cff87	2025-11-03	Expense	100	100.00	10000.00	2025-11-03 17:55:46.769494+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0053	\N
19174d80-0546-47e2-b739-f11267a8f697	d5a1699b-e816-4560-b055-433d69949c23	2025-10-28	Office to MadChef Office Banani Agreement Signing	1	200.00	200.00	2025-11-04 12:32:33.621973+06	10	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0055	\N
c17e0e64-d030-4bd7-a7c6-f9730652409d	\N	2025-09-01	Salary - Md Sajibur Rahman (Support Eng) Sep 2025	1	13000.00	13000.00	2025-10-22 18:55:25.484353+06	11	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	10018	clw-ex-0020	\N
f430b2e0-41a4-48aa-9e1a-a8d96cd54962	\N	2025-10-29	Expense	1	1400.00	1400.00	2025-11-04 12:35:58.947777+06	17	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0057	\N
4c934f4d-7d9e-4bed-8bcf-9e6b08dc9d66	\N	2025-09-01	Salary - Md. Sohel Rana (Accounts)-Sep 2025	1	18000.00	18000.00	2025-10-22 18:55:06.780814+06	11	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	10016	clw-ex-0019	\N
747899da-366c-419f-a3bd-830463216df4	d5a1699b-e816-4560-b055-433d69949c23	2025-10-30	MadChef Baily Road Machine Carrying Cost 	1	2600.00	2600.00	2025-10-30 16:41:31.495621+06	19	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0051	\N
a4a6eaf3-a6da-447f-a537-8244d1cc61d5	\N	2025-09-01	Salary - Md. Arman Al Sharif - Sep 2025	1	48000.00	48000.00	2025-10-22 18:54:01.88964+06	11	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	10006	clw-ex-0017	\N
e053a5ed-b6e4-493a-922e-b180b21d51c7	\N	2025-09-01	Salary - Badhon Roy(Engineer) - Sep 2025	1	18000.00	18000.00	2025-10-22 18:54:45.152932+06	11	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	10011	clw-ex-0018	\N
aec8bf09-12b6-43c8-a0ee-75d02a342bef	b873dc83-b55c-4fdc-98b9-7dc25e9d5a10	2025-10-26	Expense	50	100.00	5000.00	2025-10-26 17:06:23.87009+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0041	\N
c8ec2c0f-cbe2-4222-82f1-89bc235f2cca	b5327e30-7b83-4fda-99aa-99a107bbcca9	2025-10-27	Expense	100	100.00	10000.00	2025-10-27 17:52:52.606062+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0043	\N
3f2546ab-d840-47fe-a9d7-8891e8d9e618	72cbe2e1-4a91-425e-8a53-71533ffbdb0e	2025-10-07	Expense	50	100.00	5000.00	2025-10-23 11:27:12.449525+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0033	\N
386b6679-0887-4acd-873d-1b5651d17158	\N	2025-10-01	Expense	1	18000.00	18000.00	2025-11-04 12:38:54.938338+06	11	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	10016	clw-ex-0059	\N
f936ff30-7341-4399-bd9d-f97e92be5225	3869bce6-8e5d-4e64-9197-24400000d168	2025-10-27	Expense	100	100.00	10000.00	2025-10-27 18:00:38.55022+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0045	\N
8b8cfa7e-3d13-4601-a417-e222d32c909f	d5a1699b-e816-4560-b055-433d69949c23	2025-10-08	Factory 	100	100.00	10000.00	2025-10-23 11:28:41.629616+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0035	\N
f11e6748-87c4-4675-abb1-a6490ce3911c	\N	2025-10-01	Expense	1	13000.00	13000.00	2025-11-04 12:39:59.381772+06	11	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	10018	clw-ex-0061	\N
49c04cdc-ff37-4b9b-a9ce-4d35f25207da	\N	2025-10-01	Expense	1	3000.00	3000.00	2025-11-04 12:41:24.791421+06	11	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	10021	clw-ex-0063	\N
b2ed583a-c81f-4ac5-baf8-8ba4f0797f12	\N	2025-10-31	Expense	1	5000.00	5000.00	2025-11-04 12:42:29.313508+06	23	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0065	\N
9234bee3-f3ec-4756-bfbc-3edca3c59368	\N	2025-10-31	Expense	1	4856.00	4856.00	2025-11-04 12:44:44.98656+06	16	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0067	\N
bc9bbaf7-e5c5-4c94-b8fa-eaec33d8b8a9	\N	2025-11-01	Ncc bank depostit - Rezaul	1	100.00	100.00	2025-11-04 12:51:50.907783+06	10	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0069	\N
cf39294a-348c-4d44-8049-fa8db5a92b7b	b957c84b-8cc1-4ee9-a24c-a80565676721	2025-11-02	Shanghigh doll delivery	1	100.00	100.00	2025-11-04 12:55:14.067005+06	17	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0071	\N
6dcd0efe-edb3-4b3c-911b-08fc07aefa34	\N	2025-11-04	Stedfast Bill	1	760.00	760.00	2025-11-04 12:56:03.998483+06	17	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0073	\N
d413bbf1-1690-4bd0-aed0-dca7338e13f7	b873dc83-b55c-4fdc-98b9-7dc25e9d5a10	2025-11-04	Expense	50	100.00	5000.00	2025-11-04 17:04:42.476559+06	18	8c018b67-1073-45ce-af3b-4c2cf980badc	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0075	\N
dca9ebd3-f9f0-4bc3-898b-f764f791642f	b5327e30-7b83-4fda-99aa-99a107bbcca9	2025-11-12	Expense	100	100.00	10000.00	2025-11-12 17:38:16.592502+06	18	8c018b67-1073-45ce-af3b-4c2cf980badc	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0079	\N
5d4b6517-1887-44df-9ba4-ba132b0a07c1	\N	2025-11-13	Stedfast Bill	1	1320.00	1320.00	2025-11-13 11:13:53.249819+06	17	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0081	\N
2084cb4c-4ff1-43e4-838c-e4e4cd68c52b	33a1a534-951a-4f86-a832-188fa5117b57	2025-11-13	Office to MadChef Dhanmondi New Machine Setup	1	100.00	100.00	2025-11-13 11:14:46.709355+06	10	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0083	\N
6698f88f-123e-4b27-b431-bcd22c825c40	33a1a534-951a-4f86-a832-188fa5117b57	2025-11-13	Jueil Vai MadChef Dhanmondi Machine delivery 	1	920.00	920.00	2025-11-13 11:15:36.509478+06	19	503f5f0e-c268-49b8-adf4-190b10c8cdcc	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0085	\N
d92d0c81-4fa8-400f-abe5-7a0f7b7ef983	\N	2025-10-27	Stamp paper 6 pcs	6	145.00	870.00	2025-10-27 18:09:42.0267+06	9	d2fabda9-ee77-4536-a783-67d66406889a	975b7b9b-f608-45c0-861d-d91695ec79e9	\N	clw-ex-0049	Stamp paper 
a009d560-3692-4313-9986-2daa5b3f1f56	\N	2025-10-06	sticker print + ( transport muyed)	1	1700.00	1700.00	2025-10-23 11:10:16.379407+06	9	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0025	Sticker(MadChef)
7aaed73d-e9c1-48e1-9fb7-7cfe2f174e4d	6d29d8b3-9777-4a01-8431-53acbcad9363	2025-11-17	Expense	100	100.00	10000.00	2025-11-17 11:21:07.943174+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0087	\N
1acd05da-aa00-435f-a8f5-a91e731c4fe0	\N	2025-10-14	Hand Tools	1	60.00	60.00	2025-10-23 11:11:22.480696+06	9	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0027	Dalie-10mm
0d547522-2e6d-4279-b01e-ec5418d8fd2a	ee68bac1-c967-4b3e-be4c-53aeba1f1249	2025-11-17	Expense	50	100.00	5000.00	2025-11-17 17:39:41.472715+06	18	d2fabda9-ee77-4536-a783-67d66406889a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	\N	clw-ex-0089	\N
\.


--
-- Data for Name: machine_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.machine_payments (id, machine_id, bank_id, payment_date, amount, remarks, created_at, invoice_id, created_by) FROM stdin;
ba6147ee-18ec-4db2-990e-19173ff40aa5	6f603dc0-90ac-4d7d-ac3a-ee7bfe9557c8	d2fabda9-ee77-4536-a783-67d66406889a	2025-10-19	16546.00	Received by Rajaul cash	2025-10-20 15:58:00.394442+06	6804c358-e42b-46f6-a423-a1d6bde9bcbb	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
193e7661-4805-496e-b862-0a26c36781e6	6ee6ed8e-bff1-43d0-a29b-1764668b2b29	d2fabda9-ee77-4536-a783-67d66406889a	2025-10-19	25354.00	Received by Rajaul cash	2025-10-20 15:58:44.885504+06	4d9c9bd1-e785-4b1f-ac2c-44a35dcd51c9	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
34bd3ad6-7810-4dd4-9a3e-55908e491881	07490f7a-5244-4e67-bcc0-4fd1df88ed92	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-10-20	3893.75	sharif bkash-15	2025-10-20 16:15:04.647152+06	7775baa6-afc0-4f78-a611-0ef48c5a4d7b	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
f5e76172-9f4b-4b31-8185-2ea116142de3	72cbe2e1-4a91-425e-8a53-71533ffbdb0e	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-10-18	4000.00	sharif bkash-	2025-10-20 16:37:36.797444+06	90b4df42-3e3e-4751-841c-3bddf5e7c685	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
37038ba8-8afd-47f4-adde-1e27aa8eac3f	b5327e30-7b83-4fda-99aa-99a107bbcca9	d2fabda9-ee77-4536-a783-67d66406889a	2025-09-28	38556.25	Received by Rajaul cash	2025-10-13 18:28:55.435396+06	ba688357-6037-495b-8074-16308ed7144f	\N
8531d68b-33c4-481c-b55d-f3d1a2c47512	74077ddb-cbfc-46de-a0b6-1e2d1b68e4aa	d2fabda9-ee77-4536-a783-67d66406889a	2025-09-30	8025.00	Received by Rajaul cash	2025-10-14 13:30:53.404116+06	1edaf64e-6ef9-4a38-97a9-3eb515c2a177	\N
32021409-55f6-4969-9910-e601ef902ec2	4f9ad276-ec83-423b-bb6a-3431e5b5d74f	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-10-15	5995.00	Shajib	2025-10-20 17:28:05.54319+06	cb423190-9e99-457b-8cd4-900fe20d3319	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
a0d0187c-8588-4749-93be-b5a574346463	277b890a-f8fe-4cb2-a106-066731d848e3	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-10-05	8000.00	sharif bkash-30	2025-10-16 11:09:23.102656+06	10529031-7ca1-49e7-bbd5-b6711a0119f7	b61a9829-5b43-41bc-b09a-3d74a0e05767
d02ccd1d-aafa-472c-b315-ed65d06ff1ae	1885a455-019b-43d3-80e6-7a4fcc1e1232	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-10-11	5087.00	sharif bkash-30	2025-10-16 11:10:11.18311+06	60c79403-7c6e-4962-ac41-080dcb53fb77	b61a9829-5b43-41bc-b09a-3d74a0e05767
99b6cabc-3fb2-4b24-ad21-4d81ee61d683	bf03337a-93fd-45a5-84c1-79fb21d59745	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-10-02	6726.25	sharif bkash-30	2025-10-16 11:10:51.762482+06	c10916aa-a1a9-445c-85b2-4633054fd9ee	b61a9829-5b43-41bc-b09a-3d74a0e05767
ad845555-1ee9-4b56-ade7-b039c3161e3c	aa75ca99-9bf5-4156-af35-4467c84f44fd	8c018b67-1073-45ce-af3b-4c2cf980badc	2025-10-05	11537.50		2025-10-16 11:13:04.381706+06	bd1c789b-3c18-4c47-8fef-cfa60fb11159	b61a9829-5b43-41bc-b09a-3d74a0e05767
d642de04-135d-4a7f-84d1-05841c72ce1e	8cb8bd6f-be4d-4964-8e10-eddd392cff87	8c018b67-1073-45ce-af3b-4c2cf980badc	2025-10-05	15012.50		2025-10-16 11:14:44.489364+06	9ab884d3-be80-4801-be6a-6008dca9d4fe	b61a9829-5b43-41bc-b09a-3d74a0e05767
c0cb50ac-188c-4422-85ff-5c8a850f1810	ae0f877f-a5b4-4955-a295-317855b3ff27	8c018b67-1073-45ce-af3b-4c2cf980badc	2025-10-05	2552.50		2025-10-16 11:15:07.085898+06	ef270f9d-fa2e-4283-834f-08ffc516d7cb	b61a9829-5b43-41bc-b09a-3d74a0e05767
e7f59f4a-e196-4c34-90b9-b707c527d94d	ee68bac1-c967-4b3e-be4c-53aeba1f1249	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-09-30	4000.00	Shajibi bkash	2025-10-16 16:36:28.599013+06	8c475278-a066-4d07-bfe8-2c8c3ff3a6cb	b61a9829-5b43-41bc-b09a-3d74a0e05767
8820bcb7-df98-44e0-bfa3-29e239b70340	b873dc83-b55c-4fdc-98b9-7dc25e9d5a10	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-09-30	3587.50	Shajibi bkash	2025-10-16 16:37:15.833524+06	8e7599fd-e273-46f0-9a28-622b94e3a94f	b61a9829-5b43-41bc-b09a-3d74a0e05767
f914e6e5-b5e3-4b2e-8d20-08b53e6100ea	4f9ad276-ec83-423b-bb6a-3431e5b5d74f	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-09-30	5315.00	Shajibi bkash	2025-10-16 16:37:55.818363+06	68323bce-d41e-40e1-aff8-f6cfa00b2394	b61a9829-5b43-41bc-b09a-3d74a0e05767
0b1353dc-4a3b-427a-acca-7cab77823456	ee68bac1-c967-4b3e-be4c-53aeba1f1249	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-10-15	3592.00	Shajibi bkash-15	2025-10-16 16:41:20.651879+06	57104d42-67c0-4056-8d65-43ff0df1d45e	b61a9829-5b43-41bc-b09a-3d74a0e05767
82de9550-b30a-4efe-b665-4e8389248abe	277b890a-f8fe-4cb2-a106-066731d848e3	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-10-18	2237.75	sharif bkash-15	2025-10-19 11:01:08.618788+06	19fada62-2490-4f28-b1ec-f092fd732672	b61a9829-5b43-41bc-b09a-3d74a0e05767
c3d36cd9-45a1-494d-8ced-a5df2a733bb5	dfbbdc7f-e2de-4351-be66-4a05ee1aa6ed	841a7673-e6b8-4f07-9d2a-5f14ee159df6	2025-10-19	4085.00		2025-10-19 17:21:34.890077+06	7c3114af-8292-4993-bf95-91acc86655e3	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
c813a567-d187-4506-ba38-4053ae04ba7b	2fd45c00-2dce-471f-a4d8-f5ede2d712c4	d2fabda9-ee77-4536-a783-67d66406889a	2025-10-19	19300.00	Received by Rajaul cash	2025-10-20 15:57:20.306628+06	1ca5bf33-f699-4265-865d-7f660324e01a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
5c0d5587-498e-4744-a750-785536509883	74077ddb-cbfc-46de-a0b6-1e2d1b68e4aa	841a7673-e6b8-4f07-9d2a-5f14ee159df6	2025-10-26	9600.00	shajib	2025-10-27 17:17:18.158049+06	7b2f818e-5d2f-4a26-9af0-8abc722031b5	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
4b6b5b6e-bba5-4295-8b9d-b15f3a3aefb6	b873dc83-b55c-4fdc-98b9-7dc25e9d5a10	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-10-20	6470.00	shajib bkash-15	2025-10-21 19:03:49.323176+06	1cdc5c7c-078d-414f-99e6-b12165388d8b	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
508877f0-5f81-442b-931d-df9354c5691b	29e89cc6-04f5-475d-8dd7-c2efe05d4c55	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-10-21	5265.00	sharif bkash	2025-10-22 10:46:56.388309+06	5b3bb8c1-db71-45fd-9813-a6647f29f76c	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
b2b68391-13f2-49c5-960e-3d806f8a8c55	29e89cc6-04f5-475d-8dd7-c2efe05d4c55	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-10-21	4815.00	sharif bkash	2025-10-22 10:47:53.066874+06	ed45916e-8234-40c9-b870-ca1b86e50160	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
b5f808ec-b25b-4b88-97f2-14b166301232	b5327e30-7b83-4fda-99aa-99a107bbcca9	d2fabda9-ee77-4536-a783-67d66406889a	2025-09-24	37500.00	Received by Shajib cash	2025-10-22 13:15:41.764379+06	468b3487-ad6b-442f-86d6-eff14c788171	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
40b1908d-6e29-486f-9d5e-f8420f5ab55e	3531f437-b29d-4f5c-8891-2463ae8e70b5	d2fabda9-ee77-4536-a783-67d66406889a	2025-09-23	18400.00	Received by Shajib cash	2025-10-22 13:16:27.809714+06	5fc4a18c-949f-4446-a95a-b082931706d1	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
72f728c5-5553-430d-87e2-e2c7f63e44ec	74077ddb-cbfc-46de-a0b6-1e2d1b68e4aa	d2fabda9-ee77-4536-a783-67d66406889a	2025-09-29	9796.00	Received by Shajib cash	2025-10-22 13:17:17.955787+06	22647618-ebd1-420d-824b-8f9ee177ef00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
cda13bc9-fe85-4b09-be6f-6704a78455e4	dfbbdc7f-e2de-4351-be66-4a05ee1aa6ed	841a7673-e6b8-4f07-9d2a-5f14ee159df6	2025-09-18	2282.00		2025-10-22 13:18:04.787492+06	998f54d2-a739-4e08-9f89-192de04b7f68	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
0b6df67e-866d-49c4-9997-204b4b167973	29e89cc6-04f5-475d-8dd7-c2efe05d4c55	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-09-17	4000.00	sharif bkash-15	2025-10-22 13:18:49.306101+06	40a3c156-2337-4657-97c3-1fc281053bfb	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
67b4468f-fc58-4cfa-8f78-cd87395a8a48	b873dc83-b55c-4fdc-98b9-7dc25e9d5a10	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-09-24	4070.00	sharif bkash-15	2025-10-22 13:20:47.181142+06	b469538e-1104-46fe-a067-091630c9831b	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
5880bba3-4eba-4de4-a50e-f69317339fa3	4f9ad276-ec83-423b-bb6a-3431e5b5d74f	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-09-19	5430.00	shajib bkash-15	2025-10-22 13:21:24.596908+06	724d0837-5889-4e84-8d52-3baa2453776e	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
5ca82951-427d-48da-b9a3-e5c5dc2acd39	feb921c1-425c-4a8a-8748-f7d958a7d3e0	841a7673-e6b8-4f07-9d2a-5f14ee159df6	2025-10-02	8952.00		2025-10-22 13:25:35.915915+06	526a8c38-7cf4-4103-9445-d09b43d94c38	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
bd25c0fb-26ba-4fa7-b35d-cc5cdf261908	b957c84b-8cc1-4ee9-a24c-a80565676721	841a7673-e6b8-4f07-9d2a-5f14ee159df6	2025-10-02	10548.00		2025-10-22 13:25:57.498926+06	c1d52844-af7c-46d5-a2f4-2fd26fb42bfe	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
3fafd8ff-3177-4ae9-af10-e326b4c19e9f	6d29d8b3-9777-4a01-8431-53acbcad9363	d2fabda9-ee77-4536-a783-67d66406889a	2025-09-23	4400.00	Shajib	2025-10-22 13:37:24.375042+06	2415e8c0-d670-40b0-9173-f89a9345bebf	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
a215db16-152f-45c9-893b-01424053202b	ee68bac1-c967-4b3e-be4c-53aeba1f1249	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-09-16	5975.00	shajib	2025-10-22 13:46:33.714644+06	ffa17cff-558c-44b8-b8b3-58173167a8bf	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
afcc0a09-6e48-409c-8767-5ee7e05555fd	72cbe2e1-4a91-425e-8a53-71533ffbdb0e	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-10-07	4868.75	sharif bkash-15	2025-10-22 13:47:28.54366+06	4542d8d8-182a-4f1b-8dbe-7a9ae6ce7d10	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
ec656997-79d2-410f-bb36-2cdaa524ebe1	b957c84b-8cc1-4ee9-a24c-a80565676721	841a7673-e6b8-4f07-9d2a-5f14ee159df6	2025-10-21	9852.00		2025-10-23 10:36:19.5036+06	2b8f2d71-505c-49e5-83e9-953eba7154e0	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
6805595f-b627-4534-a952-9eab0813a9c8	feb921c1-425c-4a8a-8748-f7d958a7d3e0	841a7673-e6b8-4f07-9d2a-5f14ee159df6	2025-10-22	12498.00		2025-10-23 10:37:35.650424+06	6b82d9e1-1030-446a-82c9-d5db1d60152b	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
20bc4b95-3d25-4564-be33-af64d01447c4	b957c84b-8cc1-4ee9-a24c-a80565676721	841a7673-e6b8-4f07-9d2a-5f14ee159df6	2025-10-22	4158.00		2025-10-23 10:37:59.301005+06	05a29ec7-5290-48fe-a93d-a5dc3782eaaf	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
39638ef2-d15b-40bd-9991-a588ff4f6b1a	feb921c1-425c-4a8a-8748-f7d958a7d3e0	841a7673-e6b8-4f07-9d2a-5f14ee159df6	2025-10-22	9036.00		2025-10-23 10:38:26.435734+06	2b1a4eef-c85d-4c7e-9505-34dd51e746ee	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
b5e9635c-c280-4749-beed-b061c929b3b5	bf03337a-93fd-45a5-84c1-79fb21d59745	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-10-23	4798.00	Sharif Vai	2025-10-23 13:33:02.832209+06	5139b4d7-5c0d-42e5-ba24-00962089bd0a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
ae083adc-e6e0-44c3-9627-a5fbc64f408c	72cbe2e1-4a91-425e-8a53-71533ffbdb0e	d2fabda9-ee77-4536-a783-67d66406889a	2025-09-30	697.50	the stories cafe 30 sep 2025 \nsales adjustment with food rail(due to remove the machine)	2025-10-24 21:25:37.841358+06	4542d8d8-182a-4f1b-8dbe-7a9ae6ce7d10	975b7b9b-f608-45c0-861d-d91695ec79e9
b7ced6f3-2e6f-45cc-94bf-f46428605914	07490f7a-5244-4e67-bcc0-4fd1df88ed92	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-10-05	3305.75	sharif bkash-30	2025-10-16 11:28:47.267296+06	fc3fa8a4-b8cb-46c8-9d79-fd12a702b2c7	b61a9829-5b43-41bc-b09a-3d74a0e05767
38209d41-af44-4261-b91e-cde81d157f23	07490f7a-5244-4e67-bcc0-4fd1df88ed92	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-09-25	4655.88	sharif bkash-15	2025-10-22 13:26:51.968513+06	0ddb3608-b727-4e99-be09-b7809537c8af	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
ce3600b0-3695-41d2-9c2a-8c1b2abc1366	4c5dda16-9682-4bba-aed0-c38e82ec5356	d2fabda9-ee77-4536-a783-67d66406889a	2025-10-29	7100.00	Rajul Vai	2025-10-30 10:09:36.788228+06	8fd198de-b3bf-472e-9363-f720655f1514	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
f2550e3a-4939-4f97-93f3-d8d2b40ce551	b5327e30-7b83-4fda-99aa-99a107bbcca9	841a7673-e6b8-4f07-9d2a-5f14ee159df6	2025-10-20	37500.00	Received by Rajaul cash	2025-10-21 18:52:36.613107+06	8c86e40d-60cf-4b06-a0ae-bb2278216b5b	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
48e14eeb-22d8-4cc4-84ae-c97fea7eca40	3531f437-b29d-4f5c-8891-2463ae8e70b5	841a7673-e6b8-4f07-9d2a-5f14ee159df6	2025-10-19	10090.00		2025-10-21 16:28:03.022353+06	1329d001-e4bf-4624-be6d-a4e04f13e54e	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
b195c077-72fb-41e3-aa36-10bf54e631f5	3531f437-b29d-4f5c-8891-2463ae8e70b5	8c018b67-1073-45ce-af3b-4c2cf980badc	2025-10-18	13300.00		2025-10-21 16:27:42.394235+06	140362ff-e43a-4cad-8f61-e9b40be43c31	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
5a90df3f-1491-4fe9-9dba-d558d31b18b4	b084d7e5-1c69-4d42-9650-3b2ee45443d3	8c018b67-1073-45ce-af3b-4c2cf980badc	2025-10-05	6327.50		2025-11-02 16:06:18.317649+06	4e6cd023-e793-4195-8a78-3232ab9504c6	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
8d3cebbb-0c10-45f3-ba53-91c8cafb3f41	4f9ad276-ec83-423b-bb6a-3431e5b5d74f	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-03	5480.00	sharif bkash-31	2025-11-03 18:18:55.406669+06	d5b5e2c5-f97b-401a-a245-41037f13cf5e	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
daa7f581-2851-4cff-be67-512738b692cb	07490f7a-5244-4e67-bcc0-4fd1df88ed92	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-03	3066.00	sharif bkash-31	2025-11-03 18:19:22.442466+06	09e86a21-078c-44b6-9543-59deea61a494	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
2368c131-01ed-4542-94b2-1c5ae6c50276	72cbe2e1-4a91-425e-8a53-71533ffbdb0e	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-03	2048.75	Sharif vai	2025-11-04 11:18:04.36625+06	90b4df42-3e3e-4751-841c-3bddf5e7c685	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
a7181939-d518-47af-9eca-5cde852e3fc2	72cbe2e1-4a91-425e-8a53-71533ffbdb0e	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-03	3952.00	sharif vai	2025-11-04 11:18:56.684104+06	11de7713-28b5-4f5b-a63b-0ac73bec529d	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
9c68cff7-c909-4787-9abb-aaa803094c05	ee68bac1-c967-4b3e-be4c-53aeba1f1249	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-04	7230.00	Sharif Vai	2025-11-04 14:59:51.730393+06	26789a34-c804-4af0-b60c-700d22deaf32	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
9655dc5b-c542-458d-b481-d41d401820b7	6d29d8b3-9777-4a01-8431-53acbcad9363	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-05	3625.00	Sharif	2025-11-05 19:01:50.182604+06	2cb637f3-fdcc-448d-8b00-1156f8e2f4ce	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
778e08e2-cdc9-4973-a346-9495cf05d80b	6d29d8b3-9777-4a01-8431-53acbcad9363	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-05	6570.00	Sharif Vai	2025-11-05 19:02:47.884136+06	89b82af8-072a-4977-8d1f-da69c96e39d8	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
465e437b-5704-469d-b7aa-9b9a640b0cc1	d3e8eb14-b460-4f82-b334-790165c2a922	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-05	1110.00	Sharif vai 	2025-11-06 10:24:40.263296+06	b6c1c0e9-c2f2-4d95-99df-bfdd9668359b	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
8fc62193-6496-4c13-9051-616edfb5241c	d3e8eb14-b460-4f82-b334-790165c2a922	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-05	1510.00	Sharif vai 	2025-11-06 10:25:37.246314+06	5fa0762a-00af-4b36-bf0f-f136d748409f	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
b29089b4-47a3-468e-ac50-42cd3625d378	6d29d8b3-9777-4a01-8431-53acbcad9363	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-10-23	5390.00	Sharif vai 	2025-11-06 12:02:09.999012+06	ddc518ff-4803-4243-a4c6-6405e39ae6bb	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
446c350c-332a-47f9-9890-ea2537a59de5	dfbbdc7f-e2de-4351-be66-4a05ee1aa6ed	841a7673-e6b8-4f07-9d2a-5f14ee159df6	2025-11-06	4610.00		2025-11-06 12:51:24.204878+06	bb6cfbbf-7a8e-4ca5-9c9b-f4e656c61b6a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
f67f2419-626e-416d-9ba3-05fc70d46f64	1885a455-019b-43d3-80e6-7a4fcc1e1232	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-08	5800.00	Sharif vai	2025-11-08 16:14:27.792173+06	588bf3cf-6ff0-4729-bbca-29b6d79ba674	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
b13f4240-f2e5-45d9-8bd6-a9ff8699002d	29e89cc6-04f5-475d-8dd7-c2efe05d4c55	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-08	6610.00	Sharif Vai 	2025-11-09 10:28:29.92847+06	1fb7bbfc-31c5-4a96-8de1-5ef458219493	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
d4444c2f-832d-40df-a2d8-eeb446435118	bf03337a-93fd-45a5-84c1-79fb21d59745	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-08	7216.00	Sharif vai	2025-11-09 10:29:38.899091+06	6b0bfbe3-378e-4fbe-95e3-37a49a2063ba	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
5db6449c-9e7e-4278-96b0-2eeaa426760b	277b890a-f8fe-4cb2-a106-066731d848e3	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-09	2097.00	Sharif Vai 	2025-11-10 10:36:45.078871+06	ad1885d8-47ba-4c3a-95f8-dc42b8667151	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
f2ac2449-1896-4b5d-9566-877e82da3eef	b873dc83-b55c-4fdc-98b9-7dc25e9d5a10	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-11	4240.00	Shajib	2025-11-11 12:49:48.283966+06	2a66d064-bda6-4ad5-bda3-ee73dfc54f5e	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
345231e5-a75e-41ef-83a1-099289d8dbdc	3869bce6-8e5d-4e64-9197-24400000d168	8c018b67-1073-45ce-af3b-4c2cf980badc	2025-11-11	19100.00		2025-11-11 13:01:55.044639+06	066febcc-d276-41ee-a9e1-84bcea64803e	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
6ec769ef-0633-4bc0-b0ce-28ab56ea658f	3869bce6-8e5d-4e64-9197-24400000d168	8c018b67-1073-45ce-af3b-4c2cf980badc	2025-11-11	24100.00		2025-11-11 13:02:47.431142+06	3ac79576-2cf2-44ff-8237-179a934c933f	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
dd4ea9c0-246c-4658-bbf6-1f1b7871ab01	b084d7e5-1c69-4d42-9650-3b2ee45443d3	8c018b67-1073-45ce-af3b-4c2cf980badc	2025-11-13	6767.50		2025-11-13 10:44:30.253806+06	4bc5f925-fe9c-4308-8c8d-41827138d85e	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
d2f66fb1-cbeb-4bb0-90a8-eec0198c0b17	ae0f877f-a5b4-4955-a295-317855b3ff27	8c018b67-1073-45ce-af3b-4c2cf980badc	2025-11-13	5237.50		2025-11-13 10:44:46.922888+06	e3b8447f-0229-4f91-9004-58bac2b510c1	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
ea3043c2-9fc6-4cfd-af1a-b7a6ce0e03b4	aa75ca99-9bf5-4156-af35-4467c84f44fd	8c018b67-1073-45ce-af3b-4c2cf980badc	2025-11-13	9432.50		2025-11-13 10:45:07.07875+06	6f49a417-220f-417a-8c66-74b78d71acd4	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
fb6f3fe0-f52e-459f-9eb3-a8793941366a	8cb8bd6f-be4d-4964-8e10-eddd392cff87	8c018b67-1073-45ce-af3b-4c2cf980badc	2025-11-13	14742.50		2025-11-13 10:45:35.740601+06	67532dc1-c754-4433-ba08-c9d301bb256f	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
e9c67a65-d1ab-4afa-9911-2a02420e1e39	1885a455-019b-43d3-80e6-7a4fcc1e1232	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-13	2988.00	Sharif Vai	2025-11-13 12:26:57.20134+06	eda4423b-6f0e-4741-81af-44cf7abebc6f	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
ec37cdbf-996b-44dd-a0b1-4843574b0cff	feb921c1-425c-4a8a-8748-f7d958a7d3e0	841a7673-e6b8-4f07-9d2a-5f14ee159df6	2025-11-15	8118.00		2025-11-16 10:27:51.67607+06	935718f6-77a9-4104-a238-547d56abc38c	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
06bec2b7-bb45-4bae-9c3b-5bd78b9bf323	b957c84b-8cc1-4ee9-a24c-a80565676721	841a7673-e6b8-4f07-9d2a-5f14ee159df6	2025-11-15	10032.00		2025-11-16 10:28:51.089588+06	74ef0a2b-1343-4234-8fac-3bff42e1989a	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
b2c96bf7-81d4-4918-b387-97a1ca99036e	ee68bac1-c967-4b3e-be4c-53aeba1f1249	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-16	4410.00	Sharif Vai	2025-11-16 15:13:29.271106+06	4780ac53-7c57-4aaa-bdeb-c848430566c8	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
e267a81d-ae22-4001-aa7e-d1dc2b174dff	4f9ad276-ec83-423b-bb6a-3431e5b5d74f	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-15	4285.00	Sharif Vai	2025-11-16 16:19:01.480959+06	4738565c-35bc-4fb5-a7c5-9c1b3c33cab4	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
b3a2f11a-68f4-41d0-a28e-3f90d6f87370	dfbbdc7f-e2de-4351-be66-4a05ee1aa6ed	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-16	2000.00	Shajib	2025-11-17 15:42:41.748361+06	d0259d7e-2f38-4a48-a8a2-37b42eef80ef	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
178fab76-1484-4477-a2ca-9229a0f904c0	4c5dda16-9682-4bba-aed0-c38e82ec5356	d2fabda9-ee77-4536-a783-67d66406889a	2025-11-17	3323.00		2025-11-19 10:51:25.075909+06	e68d61d9-c975-4eb8-8d37-7faa18c2f7b9	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
648eef5d-0bca-4fa7-8a0f-2008330eb02e	277b890a-f8fe-4cb2-a106-066731d848e3	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-17	2525.00	Sharif Vai 	2025-11-19 10:53:40.505883+06	c62ab849-ee33-46d6-b35e-e6cf25bcb920	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
e6fcbc69-eada-4a26-a58d-c98a2170af3a	d5a1699b-e816-4560-b055-433d69949c23	841a7673-e6b8-4f07-9d2a-5f14ee159df6	2025-11-18	13812.00		2025-11-19 13:39:52.316291+06	1617e0a9-2714-48b0-ba78-d0a5d1df38bb	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
fb9900eb-ec17-48d2-a684-ffb27337de4f	dfbbdc7f-e2de-4351-be66-4a05ee1aa6ed	841a7673-e6b8-4f07-9d2a-5f14ee159df6	2025-11-19	4047.00		2025-11-19 15:03:16.641547+06	9502e834-312f-4841-84ed-e4474ac07177	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
3f3278fd-3c5f-4b24-813b-1dec506c880b	74077ddb-cbfc-46de-a0b6-1e2d1b68e4aa	d2fabda9-ee77-4536-a783-67d66406889a	2025-11-19	5700.00	cash received by rafid	2025-11-19 17:11:18.333074+06	ffa1cd3e-4869-432f-87e8-e591183dd93b	b61a9829-5b43-41bc-b09a-3d74a0e05767
e0e87f07-9412-41a1-aa26-8fc9c0dc745d	72cbe2e1-4a91-425e-8a53-71533ffbdb0e	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-19	3658.00	Sharif Vai	2025-11-20 10:28:55.214051+06	78782288-7419-4f68-bbe3-377e0eac6944	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
551d5e9c-1d74-4f91-94fb-21fd5ab4f88f	07490f7a-5244-4e67-bcc0-4fd1df88ed92	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-20	5166.00	Sharif Vai	2025-11-20 13:15:50.911241+06	142a358b-9c9d-48ed-a1a8-c3e8eadbb319	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
f4fd629e-721e-432f-8046-e09d12b1175d	2fd45c00-2dce-471f-a4d8-f5ede2d712c4	d2fabda9-ee77-4536-a783-67d66406889a	2025-11-23	18844.00		2025-11-22 20:53:46.868727+06	a47a0b58-1e18-4034-926f-bc832163c53f	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
b268b8a3-b310-4340-b6ae-4ea8b43e646a	6ee6ed8e-bff1-43d0-a29b-1764668b2b29	d2fabda9-ee77-4536-a783-67d66406889a	2025-11-23	26736.00		2025-11-22 20:54:33.245427+06	1f19dc8a-8804-4820-9371-367147438041	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
d563ca8f-2825-4382-b951-e460910db36f	6f603dc0-90ac-4d7d-ac3a-ee7bfe9557c8	d2fabda9-ee77-4536-a783-67d66406889a	2025-11-22	13620.00		2025-11-22 20:54:06.328268+06	3c9859bc-2442-4046-ad2b-fb4169cae9f4	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
0061916e-759b-4308-aba8-808a7ea44233	b873dc83-b55c-4fdc-98b9-7dc25e9d5a10	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-23	3160.00	Shajib	2025-11-23 11:07:02.707175+06	8742c1ad-3033-4c61-b60e-247cab753def	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
f7ad26c2-3a13-4433-9d30-2bd589c21701	29e89cc6-04f5-475d-8dd7-c2efe05d4c55	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-22	3330.00	Sharif 	2025-11-23 11:07:27.984579+06	c623e8b0-6e14-442f-a666-26dfca787578	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
b59f4e9d-ce76-4412-b164-3d07c28a9433	6d29d8b3-9777-4a01-8431-53acbcad9363	503f5f0e-c268-49b8-adf4-190b10c8cdcc	2025-11-20	4110.00	Sharif	2025-11-23 11:09:14.072012+06	4fd45151-0731-4c86-a6f4-c1a0ff6ba480	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27
\.


--
-- Data for Name: machines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.machines (id, machine_name, machine_number, esp_id, franchise_id, branch_location, installation_date, initial_coin_counter, initial_prize_counter, notes, created_at) FROM stdin;
2fd45c00-2dce-471f-a4d8-f5ede2d712c4	Pizzburg Gulshan	1	pizzaburg_gulshan_0022	29248edb-d4a3-4a78-9800-a10f60ad3488	Gulshan	2023-08-22	34223	3092	sff	2025-10-12 10:50:21.479401+06
bf03337a-93fd-45a5-84c1-79fb21d59745	Fino 	15	Clowee_0006	643bfd3f-24b6-491c-bed7-2d7d17968924	Uttara	2025-09-06	27	12		2025-10-13 17:21:29.062237+06
6f603dc0-90ac-4d7d-ac3a-ee7bfe9557c8	Pizzburg Mirpur	2	pizzaburg_mirpur_0023\t	29248edb-d4a3-4a78-9800-a10f60ad3488	Mirpur	2023-08-22	3795	2139		2025-10-12 11:09:40.887631+06
6ee6ed8e-bff1-43d0-a29b-1764668b2b29	Pizzburg Dhanmondi	3	pizzaburg_dhanmondi_0024	29248edb-d4a3-4a78-9800-a10f60ad3488	Dhanmondi	2025-10-12	47361	2825		2025-10-12 11:15:57.240551+06
b5327e30-7b83-4fda-99aa-99a107bbcca9	The Cafe Rio Mirpur	6	Cafe_Rio_Mirpur_39	cd9b585a-fefd-44bf-a97e-7d9b3624126d	Mirpur	2025-10-12	51120	3334		2025-10-12 11:37:41.794156+06
74077ddb-cbfc-46de-a0b6-1e2d1b68e4aa	The Cafe Rio Mohammadpur 	5	Cafe_Rio_Mohammadpur_03	cd9b585a-fefd-44bf-a97e-7d9b3624126d	Mohammadpur	2025-10-12	20424	1376		2025-10-12 17:53:17.776646+06
aa75ca99-9bf5-4156-af35-4467c84f44fd	The Dining Lounge Wari	9	dinning_lounge_wari_0033	45f8ecfd-161e-476c-80eb-ad4655cdb752	Wari	2024-02-08	19431	1200		2025-10-12 18:39:00.511858+06
8cb8bd6f-be4d-4964-8e10-eddd392cff87	The Dining Lounge Narayanganj	10	dinning_lounge_narayangonj_0027	45f8ecfd-161e-476c-80eb-ad4655cdb752	Narayanganj	2025-10-12	35744	2879		2025-10-12 18:40:30.018196+06
ae0f877f-a5b4-4955-a295-317855b3ff27	The Dining Lounge Khilgaon	8	Dining_Lounge_Khilgaon	45f8ecfd-161e-476c-80eb-ad4655cdb752	Khilgaon	2024-03-04	12916	1394		2025-10-12 18:42:44.275018+06
3869bce6-8e5d-4e64-9197-24400000d168	Baily Deli\t	17	Baily_Deli_0026	01e5be66-b965-4adb-bc9a-2cfa16954161	Bailey Rd	2023-09-20	11690	6849		2025-10-12 18:51:34.753072+06
29e89cc6-04f5-475d-8dd7-c2efe05d4c55	Crush Station Sonir Akhra	13	crush_station_sonirakhra_0047	c41a6043-e460-480b-a569-430c96d00541	Sonir Akhra	2024-05-14	52161	3647		2025-10-13 17:00:13.889636+06
4f9ad276-ec83-423b-bb6a-3431e5b5d74f	Crush Station Narayanganj	14	crush_station_narayanganj_0048	c41a6043-e460-480b-a569-430c96d00541	Narayanganj	2025-10-13	14037	42481		2025-10-13 17:06:34.204629+06
ee68bac1-c967-4b3e-be4c-53aeba1f1249	Crush Station Uttara	11	Crush_Station_Uttara_0045	c41a6043-e460-480b-a569-430c96d00541	Uttara	2024-10-20	15873	2171		2025-10-13 17:09:02.870478+06
b873dc83-b55c-4fdc-98b9-7dc25e9d5a10	Crush Station Dhanmondi	12	Crush_Station_Dhanmondi_37	c41a6043-e460-480b-a569-430c96d00541	Dhanmondi	2024-10-17	25639	1604		2025-10-13 17:10:21.114507+06
277b890a-f8fe-4cb2-a106-066731d848e3	Fuoco Uttara	16	Fuoco_Mirpur_35	ab390752-da90-4d3f-9a9d-1f2f4b2f5eae	Uttara	2025-10-13	9199	1295		2025-10-13 17:16:09.960621+06
dfbbdc7f-e2de-4351-be66-4a05ee1aa6ed	Keedlee CTG 	20	keedlee_0049	c754765f-279d-4800-88dd-c08b89803b36	CTG	2025-03-02	6096	1932		2025-10-13 17:23:43.311615+06
feb921c1-425c-4a8a-8748-f7d958a7d3e0	Shang High Restaurant-1	27	Shang_High_Restaurant_53	c9168bd5-0b15-49dc-9a35-cc5b52535600	Dhanmondi	2025-08-12	1105	775		2025-10-13 17:26:52.111616+06
b957c84b-8cc1-4ee9-a24c-a80565676721	Shang High Restaurant-2	28	Shang_High_Restaurant_54	c9168bd5-0b15-49dc-9a35-cc5b52535600	Dhanmondi	2025-08-12	16227	975		2025-10-13 17:28:23.615687+06
72cbe2e1-4a91-425e-8a53-71533ffbdb0e	Food Rail	26	Food_Rail_52	d2f93e6d-44a3-4fbf-9a2b-e74661e0ea7a	Mirpur	2025-07-01	2370	912		2025-10-13 17:33:08.034646+06
6d29d8b3-9777-4a01-8431-53acbcad9363	Chick E Cheese Narayangonj	19	Chick_E_Cheese_0046	c41a6043-e460-480b-a569-430c96d00541	Narayanganj	2024-04-12	6548	1773		2025-10-13 17:35:03.722062+06
4c5dda16-9682-4bba-aed0-c38e82ec5356	ChefMate Lounge	24	Clowee_00024	5ff5d038-a23e-431e-a26c-e98a0bcac2ed	Dhanmondi	2025-09-18	46	15	[STATUS:active]	2025-10-13 17:44:38.759773+06
b084d7e5-1c69-4d42-9650-3b2ee45443d3	The Dining Lounge Uttara	7	Dining_Lounge_Uttara_41	45f8ecfd-161e-476c-80eb-ad4655cdb752	Uttara	2024-05-04	26237	1942	[STATUS:active]	2025-10-12 18:44:22.163041+06
d3e8eb14-b460-4f82-b334-790165c2a922	Chick E Cheese Sonir Akhra	18	Cafe_Rio_Mirpur_2_39	c41a6043-e460-480b-a569-430c96d00541	Sonir Akhra	2024-05-13	6032	2111	[STATUS:active]	2025-10-13 17:36:43.640884+06
3531f437-b29d-4f5c-8891-2463ae8e70b5	The Cafe Rio Uttara 	4	Cafe_Rio_Uttara_2_40	cd9b585a-fefd-44bf-a97e-7d9b3624126d	Uttara	2024-05-13	36493	3004	[STATUS:active]	2025-10-12 17:51:39.119882+06
d5a1699b-e816-4560-b055-433d69949c23	MadChef Baily Road 	22	ESP32_Clowee_00022	9f092d84-60ed-481b-9466-ec5862e4acf9	Baily Road	2025-10-30	40	591	[STATUS:active]	2025-10-30 16:41:00.627054+06
33a1a534-951a-4f86-a832-188fa5117b57	MadChef Dhanmondi	23	\tESP32_Clowee_00023	9f092d84-60ed-481b-9466-ec5862e4acf9	Dhanmondi	2025-11-12	10850	24695	[STATUS:active]	2025-11-12 12:18:31.528824+06
07490f7a-5244-4e67-bcc0-4fd1df88ed92	Kolapata	29	Kolapata_Narayanganj_0045	3002befd-50db-4aca-964e-9476d0521850	Narayanganj	2024-09-18	17789	1045	[STATUS:active]	2025-10-16 11:25:19.515851+06
1885a455-019b-43d3-80e6-7a4fcc1e1232	Mr. Manik Food's Uttara	21	Manik_Foods_41	9bbb9704-569c-4293-bbf8-df983d8ed37b	Uttara	2024-06-03	9915	24645	[STATUS:inactive]	2025-10-13 17:48:46.330038+06
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, notification_type, message, related_module, user_id, status, created_at) FROM stdin;
3c80c840-0be8-4a50-b083-56820aeb4c8d	Info	Database backup completed	System	\N	read	2025-10-15 16:40:32.729643+06
41059d52-ae2a-4a79-8e92-2a2acfe0d363	Success	New franchise onboarded	Franchises	\N	read	2025-10-15 16:40:32.729643+06
e7105504-9ed9-4b75-a346-c378809931c9	Info	Monthly report generated	Reports	\N	read	2025-10-15 16:40:32.729643+06
89367c39-44f6-4fdd-b20b-082881f5de78	Warning	Low inventory alert for Machine #001	Machines	\N	read	2025-10-15 16:40:32.729643+06
027819bf-5c5d-4447-b92c-0bd2aff08b5a	Success	System initialized successfully	System	\N	read	2025-10-15 16:40:32.729643+06
\.


--
-- Data for Name: price_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.price_history (id, franchise_id, effective_date, coin_price, doll_price, electricity_cost, vat_percentage, created_at) FROM stdin;
\.


--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales (id, machine_id, franchise_id, sales_date, coin_sales, sales_amount, prize_out_quantity, prize_out_cost, created_at, invoice_number, payment_status, coin_adjustment, prize_adjustment, adjustment_notes, vat_amount, net_sales_amount, clowee_profit, pay_to_clowee, created_by, amount_adjustment, electricity_cost) FROM stdin;
1ca5bf33-f699-4265-865d-7f660324e01a	2fd45c00-2dce-471f-a4d8-f5ede2d712c4	29248edb-d4a3-4a78-9800-a10f60ad3488	2025-09-30	1072	26800.00	110	14300.00	2025-10-12 10:58:35.292683+06	clw/01/2025/09	Due	58	-52	\N	0.00	26800.00	5000.00	19300.00	\N	0.00	0.00
6804c358-e42b-46f6-a423-a1d6bde9bcbb	6f603dc0-90ac-4d7d-ac3a-ee7bfe9557c8	29248edb-d4a3-4a78-9800-a10f60ad3488	2025-09-30	937	23425.00	92	11960.00	2025-10-12 11:12:53.286852+06	clw/02/2025/09	Due	16	-25	\N	0.00	23425.00	4586.00	16546.00	\N	0.00	0.00
8e7599fd-e273-46f0-9a28-622b94e3a94f	b873dc83-b55c-4fdc-98b9-7dc25e9d5a10	c41a6043-e460-480b-a569-430c96d00541	2025-09-30	203	5075.00	15	2100.00	2025-10-14 11:03:59.820352+06	clw/12/2025/09H2	Due	0	0	\N	0.00	5075.00	1487.50	3587.50	\N	0.00	0.00
8c475278-a066-4d07-bfe8-2c8c3ff3a6cb	ee68bac1-c967-4b3e-be4c-53aeba1f1249	c41a6043-e460-480b-a569-430c96d00541	2025-09-30	236	5900.00	15	2100.00	2025-10-14 11:04:43.348661+06	clw/11/2025/09H2	Due	0	3	\N	0.00	5900.00	1900.00	4000.00	\N	0.00	0.00
68323bce-d41e-40e1-aff8-f6cfa00b2394	4f9ad276-ec83-423b-bb6a-3431e5b5d74f	c41a6043-e460-480b-a569-430c96d00541	2025-09-30	358	8950.00	12	1680.00	2025-10-14 11:05:33.525467+06	clw/14/2025/09H2	Due	15	0	\N	0.00	8950.00	3635.00	5315.00	\N	0.00	0.00
ed45916e-8234-40c9-b870-ca1b86e50160	29e89cc6-04f5-475d-8dd7-c2efe05d4c55	c41a6043-e460-480b-a569-430c96d00541	2025-09-30	262	6550.00	22	3080.00	2025-10-14 11:06:28.708681+06	clw/13/2025/09H2	Due	11	-2	\N	0.00	6550.00	1735.00	4815.00	\N	0.00	0.00
6b82d9e1-1030-446a-82c9-d5db1d60152b	feb921c1-425c-4a8a-8748-f7d958a7d3e0	c9168bd5-0b15-49dc-9a35-cc5b52535600	2025-09-30	591	17730.00	31	4650.00	2025-10-14 11:55:06.014358+06	clw/27/2025/09H2	Due	141	0	\N	0.00	17730.00	7848.00	12498.00	\N	0.00	0.00
2b8f2d71-505c-49e5-83e9-953eba7154e0	b957c84b-8cc1-4ee9-a24c-a80565676721	c9168bd5-0b15-49dc-9a35-cc5b52535600	2025-09-30	474	14220.00	22	3300.00	2025-10-14 11:55:35.031259+06	clw/28/2025/09H2	Due	261	0	\N	0.00	14220.00	6552.00	9852.00	\N	0.00	0.00
ddc518ff-4803-4243-a4c6-6405e39ae6bb	6d29d8b3-9777-4a01-8431-53acbcad9363	c41a6043-e460-480b-a569-430c96d00541	2025-09-30	336	8400.00	17	2380.00	2025-10-14 12:06:11.149945+06	clw/19/2025/09H2	Due	1	-2	\N	0.00	8400.00	3010.00	5390.00	\N	0.00	0.00
5fa0762a-00af-4b36-bf0f-f136d748409f	d3e8eb14-b460-4f82-b334-790165c2a922	c41a6043-e460-480b-a569-430c96d00541	2025-09-30	104	2600.00	3	420.00	2025-10-14 12:09:45.237288+06	clw/18/2025/09H2	Due	24	0	\N	0.00	2600.00	1090.00	1510.00	\N	0.00	0.00
60c79403-7c6e-4962-ac41-080dcb53fb77	1885a455-019b-43d3-80e6-7a4fcc1e1232	9bbb9704-569c-4293-bbf8-df983d8ed37b	2025-09-30	260	6500.00	24	3360.00	2025-10-14 12:30:24.084802+06	clw/21/2025/09	Due	61	-21	\N	0.00	6500.00	1413.00	5087.00	\N	0.00	0.00
c10916aa-a1a9-445c-85b2-4633054fd9ee	bf03337a-93fd-45a5-84c1-79fb21d59745	643bfd3f-24b6-491c-bed7-2d7d17968924	2025-09-30	364	9100.00	28	4200.00	2025-10-14 11:44:42.80383+06	clw/15/2025/09H2	Due	33	-24	\N	0.00	9100.00	2205.00	6726.25	\N	0.00	169.00
e88b9c2e-e7f0-4c5d-889b-323993a779d6	3869bce6-8e5d-4e64-9197-24400000d168	01e5be66-b965-4adb-bc9a-2cfa16954161	2025-10-15	1700	42500.00	86	9460.00	2025-10-16 13:45:29.296864+06	clw/17/2025/10H1	Due	63	-42	\N	2125.00	40375.00	14684.63	25690.38	b61a9829-5b43-41bc-b09a-3d74a0e05767	0.00	0.00
5b3bb8c1-db71-45fd-9813-a6647f29f76c	29e89cc6-04f5-475d-8dd7-c2efe05d4c55	c41a6043-e460-480b-a569-430c96d00541	2025-10-15	298	7450.00	22	3080.00	2025-10-16 13:58:04.833845+06	clw/13/2025/10H1	Due	17	0	\N	0.00	7450.00	2185.00	5265.00	b61a9829-5b43-41bc-b09a-3d74a0e05767	0.00	0.00
19fada62-2490-4f28-b1ec-f092fd732672	277b890a-f8fe-4cb2-a106-066731d848e3	ab390752-da90-4d3f-9a9d-1f2f4b2f5eae	2025-10-15	120	3000.00	12	1560.00	2025-10-16 15:35:59.439263+06	clw/16/2025/10H1	Due	23	-1	\N	0.00	3000.00	684.00	2237.75	b61a9829-5b43-41bc-b09a-3d74a0e05767	0.00	0.00
05a29ec7-5290-48fe-a93d-a5dc3782eaaf	b957c84b-8cc1-4ee9-a24c-a80565676721	c9168bd5-0b15-49dc-9a35-cc5b52535600	2025-10-15	201	6030.00	9	1350.00	2025-10-19 12:36:51.74218+06	clw/28/2025/10H1	Due	217	0	\N	0.00	6030.00	2808.00	4158.00	b61a9829-5b43-41bc-b09a-3d74a0e05767	0.00	0.00
2b1a4eef-c85d-4c7e-9505-34dd51e746ee	feb921c1-425c-4a8a-8748-f7d958a7d3e0	c9168bd5-0b15-49dc-9a35-cc5b52535600	2025-10-15	422	12660.00	24	3600.00	2025-10-19 12:36:54.056613+06	clw/27/2025/10H1	Due	250	0	\N	0.00	12660.00	5436.00	9036.00	b61a9829-5b43-41bc-b09a-3d74a0e05767	0.00	0.00
5139b4d7-5c0d-42e5-ba24-00962089bd0a	bf03337a-93fd-45a5-84c1-79fb21d59745	643bfd3f-24b6-491c-bed7-2d7d17968924	2025-10-14	268	6700.00	19	2850.00	2025-10-16 11:41:06.213566+06	clw/15/2025/10H1	Due	6	0		0.00	6700.00	1925.00	4605.50	b61a9829-5b43-41bc-b09a-3d74a0e05767	0.75	0.00
7775baa6-afc0-4f78-a611-0ef48c5a4d7b	07490f7a-5244-4e67-bcc0-4fd1df88ed92	3002befd-50db-4aca-964e-9476d0521850	2025-10-15	246	6150.00	10	1400.00	2025-10-19 13:07:39.167399+06	clw/23/2025/10H1	Due	37	-5	\N	0.00	6150.00	2256.25	3893.75	b61a9829-5b43-41bc-b09a-3d74a0e05767	0.00	0.00
11de7713-28b5-4f5b-a63b-0ac73bec529d	72cbe2e1-4a91-425e-8a53-71533ffbdb0e	d2f93e6d-44a3-4fbf-9a2b-e74661e0ea7a	2025-10-15	272	6800.00	15	2250.00	2025-10-20 15:28:44.593792+06	clw/26/2025/10H1	Due	1	4	\N	0.00	6800.00	2047.50	4583.75	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
4d9c9bd1-e785-4b1f-ac2c-44a35dcd51c9	6ee6ed8e-bff1-43d0-a29b-1764668b2b29	29248edb-d4a3-4a78-9800-a10f60ad3488	2025-09-29	1588	39700.00	122	15860.00	2025-10-12 11:17:54.379438+06	clw/03/2025/09	Due	49	-12		0.00	39700.00	9536.00	25354.00	\N	42.00	0.00
8c86e40d-60cf-4b06-a0ae-bb2278216b5b	b5327e30-7b83-4fda-99aa-99a107bbcca9	cd9b585a-fefd-44bf-a97e-7d9b3624126d	2025-10-10	2271	56775.00	144	21600.00	2025-10-16 12:15:21.487841+06	clw/06/2025/10H1	Due	185	0		2838.75	53936.25	16168.13	37500.00	b61a9829-5b43-41bc-b09a-3d74a0e05767	18.13	0.00
57104d42-67c0-4056-8d65-43ff0df1d45e	ee68bac1-c967-4b3e-be4c-53aeba1f1249	c41a6043-e460-480b-a569-430c96d00541	2025-10-15	209	5225.00	14	1960.00	2025-10-16 13:02:11.171902+06	clw/11/2025/10H1	Due	0	-4		0.00	5225.00	1632.50	3592.00	b61a9829-5b43-41bc-b09a-3d74a0e05767	0.50	0.00
1cdc5c7c-078d-414f-99e6-b12165388d8b	b873dc83-b55c-4fdc-98b9-7dc25e9d5a10	c41a6043-e460-480b-a569-430c96d00541	2025-10-15	378	9450.00	25	3500.00	2025-10-16 15:42:33.750625+06	clw/12/2025/10H1	Due	0	0		0.00	9450.00	2975.00	6470.00	b61a9829-5b43-41bc-b09a-3d74a0e05767	5.00	0.00
fc3fa8a4-b8cb-46c8-9d79-fd12a702b2c7	07490f7a-5244-4e67-bcc0-4fd1df88ed92	3002befd-50db-4aca-964e-9476d0521850	2025-09-30	186	4650.00	13	1820.00	2025-10-16 11:28:07.558036+06	clw/23/2025/09H2	Due	34	0		0.00	4650.00	1415.00	3235.00	b61a9829-5b43-41bc-b09a-3d74a0e05767	0.00	0.00
1edaf64e-6ef9-4a38-97a9-3eb515c2a177	74077ddb-cbfc-46de-a0b6-1e2d1b68e4aa	cd9b585a-fefd-44bf-a97e-7d9b3624126d	2025-09-30	400	10000.00	47	7050.00	2025-10-14 10:55:00.274342+06	clw/05/2025/09H2	Due	0	0	\N	500.00	9500.00	1225.00	8025.00	\N	0.00	250.00
9ab884d3-be80-4801-be6a-6008dca9d4fe	8cb8bd6f-be4d-4964-8e10-eddd392cff87	45f8ecfd-161e-476c-80eb-ad4655cdb752	2025-09-30	812	20300.00	80	10400.00	2025-10-14 11:28:46.940629+06	clw/10/2025/09	Due	26	-3	\N	0.00	20300.00	4950.00	15012.50	\N	0.00	337.50
ef270f9d-fa2e-4283-834f-08ffc516d7cb	ae0f877f-a5b4-4955-a295-317855b3ff27	45f8ecfd-161e-476c-80eb-ad4655cdb752	2025-09-30	148	3700.00	16	2080.00	2025-10-14 11:29:37.140631+06	clw/08/2025/09	Due	6	-4	\N	0.00	3700.00	810.00	2552.50	\N	0.00	337.50
3ac79576-2cf2-44ff-8237-179a934c933f	3869bce6-8e5d-4e64-9197-24400000d168	01e5be66-b965-4adb-bc9a-2cfa16954161	2025-09-30	1635	40875.00	72	7920.00	2025-10-12 18:59:56.46755+06	clw/17/2025/09H2	Due	27	-27		2043.75	38831.25	15455.63	23327.22	\N	48.41	0.00
bd1c789b-3c18-4c47-8fef-cfa60fb11159	aa75ca99-9bf5-4156-af35-4467c84f44fd	45f8ecfd-161e-476c-80eb-ad4655cdb752	2025-09-30	664	16600.00	55	7150.00	2025-10-14 11:27:57.014243+06	clw/09/2025/09	Due	31	-2		0.00	16600.00	4725.00	11537.50	\N	0.00	337.50
ba688357-6037-495b-8074-16308ed7144f	b5327e30-7b83-4fda-99aa-99a107bbcca9	cd9b585a-fefd-44bf-a97e-7d9b3624126d	2025-09-30	2270	56750.00	158	23700.00	2025-10-12 11:45:03.33597+06	clw/06/2025/09H2	Due	401	-1		2837.50	53912.50	15106.25	38556.25	\N	0.00	250.00
10529031-7ca1-49e7-bbd5-b6711a0119f7	277b890a-f8fe-4cb2-a106-066731d848e3	ab390752-da90-4d3f-9a9d-1f2f4b2f5eae	2025-09-30	432	10800.00	39	5070.00	2025-10-16 11:08:46.100134+06	clw/16/2025/09H2	Due	63	-8	\N	0.00	10800.00	2721.75	8000.00	b61a9829-5b43-41bc-b09a-3d74a0e05767	0.00	78.25
90b4df42-3e3e-4751-841c-3bddf5e7c685	72cbe2e1-4a91-425e-8a53-71533ffbdb0e	d2f93e6d-44a3-4fbf-9a2b-e74661e0ea7a	2025-09-30	354	8850.00	20	3000.00	2025-10-20 16:36:59.569311+06	clw/26/2025/09H2	Due	100	8	\N	0.00	8850.00	2632.50	6048.75	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	169.00
7b2f818e-5d2f-4a26-9af0-8abc722031b5	74077ddb-cbfc-46de-a0b6-1e2d1b68e4aa	cd9b585a-fefd-44bf-a97e-7d9b3624126d	2025-10-15	516	12900.00	50	7500.00	2025-10-16 16:57:56.852987+06	clw/05/2025/10H1	Due	0	35		645.00	12255.00	2377.50	9600.00	b61a9829-5b43-41bc-b09a-3d74a0e05767	27.50	0.00
8fd198de-b3bf-472e-9363-f720655f1514	4c5dda16-9682-4bba-aed0-c38e82ec5356	5ff5d038-a23e-431e-a26c-e98a0bcac2ed	2025-10-15	410	10250.00	24	3600.00	2025-10-16 15:52:47.705357+06	clw/24/2025/10H1	Due	13	-1		0.00	10250.00	3325.00	6767.50	b61a9829-5b43-41bc-b09a-3d74a0e05767	-11.25	0.00
7c3114af-8292-4993-bf95-91acc86655e3	dfbbdc7f-e2de-4351-be66-4a05ee1aa6ed	c754765f-279d-4800-88dd-c08b89803b36	2025-10-15	248	6200.00	10	1500.00	2025-10-19 17:19:56.567986+06	clw/20/2025/10	Due	74	0		0.00	6200.00	2350.00	3850.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
d0259d7e-2f38-4a48-a8a2-37b42eef80ef	dfbbdc7f-e2de-4351-be66-4a05ee1aa6ed	c754765f-279d-4800-88dd-c08b89803b36	2025-09-30	220	5500.00	7	1050.00	2025-10-14 11:52:26.001275+06	clw/20/2025/09H2	Due	96	0		0.00	5500.00	2225.00	3275.00	\N	0.00	0.00
cb423190-9e99-457b-8cd4-900fe20d3319	4f9ad276-ec83-423b-bb6a-3431e5b5d74f	c41a6043-e460-480b-a569-430c96d00541	2025-10-15	390	9750.00	16	2240.00	2025-10-20 16:59:17.538245+06	clw/14/2025/10H1	Due	13	-2	\N	0.00	9750.00	3755.00	5995.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
dc95b90d-a6ea-4cbc-9c3c-63dfbdedd3b5	d3e8eb14-b460-4f82-b334-790165c2a922	c41a6043-e460-480b-a569-430c96d00541	2025-10-15	56	1400.00	2	280.00	2025-10-21 16:20:54.489341+06	clw/18/2025/10H1	Due	16	-1	\N	0.00	1400.00	560.00	840.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
1329d001-e4bf-4624-be6d-a4e04f13e54e	3531f437-b29d-4f5c-8891-2463ae8e70b5	cd9b585a-fefd-44bf-a97e-7d9b3624126d	2025-10-15	656	16400.00	34	5100.00	2025-10-21 16:26:58.477822+06	clw/04/2025/10H1	Due	1158	18	\N	820.00	15580.00	5240.00	10090.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
2cb637f3-fdcc-448d-8b00-1156f8e2f4ce	6d29d8b3-9777-4a01-8431-53acbcad9363	c41a6043-e460-480b-a569-430c96d00541	2025-10-15	234	5850.00	10	1400.00	2025-10-20 15:13:17.217168+06	clw/19/2025/10H1	Due	0	-3		0.00	5850.00	2225.00	3625.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
4542d8d8-182a-4f1b-8dbe-7a9ae6ce7d10	72cbe2e1-4a91-425e-8a53-71533ffbdb0e	d2f93e6d-44a3-4fbf-9a2b-e74661e0ea7a	2025-09-15	314	7850.00	21	3150.00	2025-10-22 12:41:08.123129+06	clw/26/2025/09H1	Due	0	0	Manual Entry\n\nThe Stories cafe adjustment\n30 sep 2025\n3 pcs doll\n36 pcs coin	0.00	7850.00	2350.00	5331.25	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	169.00
ffa17cff-558c-44b8-b8b3-58173167a8bf	ee68bac1-c967-4b3e-be4c-53aeba1f1249	c41a6043-e460-480b-a569-430c96d00541	2025-09-15	338	8450.00	25	3500.00	2025-10-22 11:38:54.905301+06	clw/11/2025/09H1	Due	0	0	Manual Entry	0.00	0.00	2475.00	5875.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
40a3c156-2337-4657-97c3-1fc281053bfb	29e89cc6-04f5-475d-8dd7-c2efe05d4c55	c41a6043-e460-480b-a569-430c96d00541	2025-09-15	220	5500.00	18	2520.00	2025-10-22 11:49:36.564911+06	clw/13/2025/09H1	Due	0	0	Manual Entry	0.00	5500.00	1490.00	4000.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	10.00	0.00
724d0837-5889-4e84-8d52-3baa2453776e	4f9ad276-ec83-423b-bb6a-3431e5b5d74f	c41a6043-e460-480b-a569-430c96d00541	2025-09-15	356	8900.00	14	1960.00	2025-10-22 11:53:01.338654+06	clw/14/2025/09H1	Due	0	0	Manual Entry	0.00	6940.00	3470.00	5430.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
2415e8c0-d670-40b0-9173-f89a9345bebf	6d29d8b3-9777-4a01-8431-53acbcad9363	c41a6043-e460-480b-a569-430c96d00541	2025-09-15	820	20500.00	48	6720.00	2025-10-22 12:09:11.351226+06	clw/19/2025/09H1	Due	0	0	Manual Entry	0.00	13779.99	6890.00	13610.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
0ddb3608-b727-4e99-be09-b7809537c8af	07490f7a-5244-4e67-bcc0-4fd1df88ed92	3002befd-50db-4aca-964e-9476d0521850	2025-09-15	223	5575.00	26	3640.00	2025-10-22 12:22:11.59163+06	clw/23/2025/09H1	Due	0	0	Manual Entry	0.00	1838.25	919.13	4655.88	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
526a8c38-7cf4-4103-9445-d09b43d94c38	feb921c1-425c-4a8a-8748-f7d958a7d3e0	c9168bd5-0b15-49dc-9a35-cc5b52535600	2025-09-15	404	12120.00	28	4200.00	2025-10-22 12:52:49.769471+06	clw/27/2025/09H1	Due	0	0	Manual Entry	0.00	7920.00	4752.00	8952.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
c1d52844-af7c-46d5-a2f4-2fd26fb42bfe	b957c84b-8cc1-4ee9-a24c-a80565676721	c9168bd5-0b15-49dc-9a35-cc5b52535600	2025-09-15	486	14580.00	30	4500.00	2025-10-22 12:54:30.893071+06	clw/28/2025/09H1	Due	0	0	Manual Entry	0.00	10080.00	6048.00	10548.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
b469538e-1104-46fe-a067-091630c9831b	b873dc83-b55c-4fdc-98b9-7dc25e9d5a10	c41a6043-e460-480b-a569-430c96d00541	2025-09-14	225	5625.00	18	2520.00	2025-10-22 11:46:22.288659+06	clw/12/2025/09H1	Due	0	0	Manual Entry	0.00	5625.00	1552.50	4070.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	2.50	0.00
998f54d2-a739-4e08-9f89-192de04b7f68	dfbbdc7f-e2de-4351-be66-4a05ee1aa6ed	c754765f-279d-4800-88dd-c08b89803b36	2025-09-14	112	2800.00	11	1650.00	2025-10-22 12:19:17.623137+06	clw/20/2025/09H1	Due	0	0	Manual Entry	0.00	2800.00	575.00	2224.50	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.50	0.00
4e6cd023-e793-4195-8a78-3232ab9504c6	b084d7e5-1c69-4d42-9650-3b2ee45443d3	45f8ecfd-161e-476c-80eb-ad4655cdb752	2025-09-30	372	9300.00	31	4030.00	2025-11-02 16:04:42.826652+06	clw/07/2025/09	Due	118	0	\N	0.00	9300.00	2635.00	6327.50	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
b6c1c0e9-c2f2-4d95-99df-bfdd9668359b	d3e8eb14-b460-4f82-b334-790165c2a922	c41a6043-e460-480b-a569-430c96d00541	2025-09-15	72	1800.00	3	420.00	2025-10-22 12:06:13.453873+06	clw/18/2025/09H1	Due	0	0	Manual Entry	0.00	1800.00	690.00	1110.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
d8bffeb1-e4b7-4705-9686-088a722a29cc	3531f437-b29d-4f5c-8891-2463ae8e70b5	cd9b585a-fefd-44bf-a97e-7d9b3624126d	2025-10-31	800	20000.00	22	3300.00	2025-11-02 12:58:31.407134+06	clw/04/2025/10H2	Due	52	0	\N	1000.00	19000.00	7850.00	10900.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
140362ff-e43a-4cad-8f61-e9b40be43c31	3531f437-b29d-4f5c-8891-2463ae8e70b5	cd9b585a-fefd-44bf-a97e-7d9b3624126d	2025-09-30	800	20000.00	54	8100.00	2025-10-21 16:23:13.721251+06	clw/04/2025/09H2	Due	55	-15	\N	1000.00	19000.00	5450.00	13300.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	250.00
5fc4a18c-949f-4446-a95a-b082931706d1	3531f437-b29d-4f5c-8891-2463ae8e70b5	cd9b585a-fefd-44bf-a97e-7d9b3624126d	2025-09-14	1208	30200.00	58	8700.00	2025-10-22 11:13:58.814116+06	clw/04/2025/09H1	Due	0	0	Manual Entry	1510.00	28690.00	9995.00	18400.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	45.00	250.00
22647618-ebd1-420d-824b-8f9ee177ef00	74077ddb-cbfc-46de-a0b6-1e2d1b68e4aa	cd9b585a-fefd-44bf-a97e-7d9b3624126d	2025-09-14	486	12150.00	57	8550.00	2025-10-22 11:18:55.982467+06	clw/05/2025/09H1	Due	0	0	Manual Entry	607.50	11542.50	1496.25	9796.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.25	250.00
468b3487-ad6b-442f-86d6-eff14c788171	b5327e30-7b83-4fda-99aa-99a107bbcca9	cd9b585a-fefd-44bf-a97e-7d9b3624126d	2025-09-15	2136	53400.00	166	24900.00	2025-10-22 11:24:40.089246+06	clw/06/2025/09H1	Due	0	0	Manual Entry	2670.00	50730.00	12915.00	37500.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	65.00	250.00
d5b5e2c5-f97b-401a-a245-41037f13cf5e	4f9ad276-ec83-423b-bb6a-3431e5b5d74f	c41a6043-e460-480b-a569-430c96d00541	2025-10-31	360	9000.00	14	1960.00	2025-11-02 13:06:23.947071+06	clw/14/2025/10H2	Due	17	0	\N	0.00	9000.00	3520.00	5480.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
1fb7bbfc-31c5-4a96-8de1-5ef458219493	29e89cc6-04f5-475d-8dd7-c2efe05d4c55	c41a6043-e460-480b-a569-430c96d00541	2025-10-31	372	9300.00	28	3920.00	2025-11-02 13:08:05.296829+06	clw/13/2025/10H2	Due	18	0	\N	0.00	9300.00	2690.00	6610.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
bb6cfbbf-7a8e-4ca5-9c9b-f4e656c61b6a	dfbbdc7f-e2de-4351-be66-4a05ee1aa6ed	c754765f-279d-4800-88dd-c08b89803b36	2025-10-31	296	7400.00	8	1200.00	2025-11-02 13:47:49.881381+06	clw/20/2025/10	Due	82	0	\N	0.00	7400.00	2790.00	4610.00	12ad4585-93b8-4559-b76b-9b4ff2dabc9a	0.00	0.00
935718f6-77a9-4104-a238-547d56abc38c	feb921c1-425c-4a8a-8748-f7d958a7d3e0	c9168bd5-0b15-49dc-9a35-cc5b52535600	2025-10-31	431	12930.00	6	900.00	2025-11-02 14:18:32.547569+06	clw/27/2025/10H2	Due	42	0	\N	0.00	12930.00	7218.00	8118.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
74ef0a2b-1343-4234-8fac-3bff42e1989a	b957c84b-8cc1-4ee9-a24c-a80565676721	c9168bd5-0b15-49dc-9a35-cc5b52535600	2025-10-31	514	15420.00	13	1950.00	2025-11-02 14:18:55.488232+06	clw/28/2025/10H2	Due	10	0	\N	0.00	15420.00	8082.00	10032.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
4bc5f925-fe9c-4308-8c8d-41827138d85e	b084d7e5-1c69-4d42-9650-3b2ee45443d3	45f8ecfd-161e-476c-80eb-ad4655cdb752	2025-10-31	428	10700.00	27	3510.00	2025-11-02 16:05:29.763053+06	clw/07/2025/10	Due	131	0	\N	0.00	10700.00	3595.00	6767.50	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
e3b8447f-0229-4f91-9004-58bac2b510c1	ae0f877f-a5b4-4955-a295-317855b3ff27	45f8ecfd-161e-476c-80eb-ad4655cdb752	2025-10-31	264	6600.00	35	4550.00	2025-11-02 16:12:12.290107+06	clw/08/2025/10	Due	7	-4	\N	0.00	6600.00	1025.00	5237.50	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
6f49a417-220f-417a-8c66-74b78d71acd4	aa75ca99-9bf5-4156-af35-4467c84f44fd	45f8ecfd-161e-476c-80eb-ad4655cdb752	2025-10-31	584	14600.00	38	4940.00	2025-11-02 16:13:01.130895+06	clw/09/2025/10	Due	37	-1	\N	0.00	14600.00	4830.00	9432.50	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
67532dc1-c754-4433-ba08-c9d301bb256f	8cb8bd6f-be4d-4964-8e10-eddd392cff87	45f8ecfd-161e-476c-80eb-ad4655cdb752	2025-10-31	832	20800.00	72	9360.00	2025-11-02 16:14:03.55513+06	clw/10/2025/10	Due	37	-7	\N	0.00	20800.00	5720.00	14742.50	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
c9fd44a2-b746-4980-be5a-5e618832b7d4	b5327e30-7b83-4fda-99aa-99a107bbcca9	cd9b585a-fefd-44bf-a97e-7d9b3624126d	2025-10-31	2344	58600.00	167	25050.00	2025-11-02 13:47:22.606249+06	clw/06/2025/10H2	Due	288	0		2930.00	55670.00	15310.00	40100.00	12ad4585-93b8-4559-b76b-9b4ff2dabc9a	10.00	0.00
588bf3cf-6ff0-4729-bbca-29b6d79ba674	1885a455-019b-43d3-80e6-7a4fcc1e1232	9bbb9704-569c-4293-bbf8-df983d8ed37b	2025-10-31	318	7950.00	23	3220.00	2025-11-02 13:27:56.218304+06	clw/21/2025/10	Due	38	0		0.00	7950.00	2365.00	5563.50	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	21.50	0.00
6b0bfbe3-378e-4fbe-95e3-37a49a2063ba	bf03337a-93fd-45a5-84c1-79fb21d59745	643bfd3f-24b6-491c-bed7-2d7d17968924	2025-10-31	380	9500.00	32	4800.00	2025-11-02 13:12:51.70925+06	clw/15/2025/10H2	Due	4	0		0.00	9500.00	2350.00	6981.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.25	0.00
ad1885d8-47ba-4c3a-95f8-dc42b8667151	277b890a-f8fe-4cb2-a106-066731d848e3	ab390752-da90-4d3f-9a9d-1f2f4b2f5eae	2025-10-31	114	2850.00	11	1430.00	2025-11-02 13:19:13.064792+06	clw/16/2025/10H2	Due	59	-5		0.00	2850.00	710.00	2061.50	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.25	0.00
066febcc-d276-41ee-a9e1-84bcea64803e	3869bce6-8e5d-4e64-9197-24400000d168	01e5be66-b965-4adb-bc9a-2cfa16954161	2025-09-15	1307	32675.00	54	5940.00	2025-10-22 10:59:08.897932+06	clw/17/2025/09H1	Due	0	0	Manual Entry	1633.75	31041.25	12550.63	18472.47	975b7b9b-f608-45c0-861d-d91695ec79e9	18.16	0.00
2a66d064-bda6-4ad5-bda3-ee73dfc54f5e	b873dc83-b55c-4fdc-98b9-7dc25e9d5a10	c41a6043-e460-480b-a569-430c96d00541	2025-10-31	261	6525.00	14	1960.00	2025-11-02 13:09:31.812931+06	clw/12/2025/10H2	Due	0	-1		0.00	6525.00	2282.50	4240.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	2.50	0.00
e68d61d9-c975-4eb8-8d37-7faa18c2f7b9	4c5dda16-9682-4bba-aed0-c38e82ec5356	5ff5d038-a23e-431e-a26c-e98a0bcac2ed	2025-10-31	200	5000.00	11	1650.00	2025-11-02 13:34:48.781748+06	clw/24/2025/10H2	Due	0	0		0.00	5000.00	1675.00	3155.50	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.75	0.00
ffa1cd3e-4869-432f-87e8-e591183dd93b	74077ddb-cbfc-46de-a0b6-1e2d1b68e4aa	cd9b585a-fefd-44bf-a97e-7d9b3624126d	2025-10-31	312	7800.00	30	4500.00	2025-11-02 13:00:10.136893+06	clw/05/2025/10H2	Due	-1	0		390.00	7410.00	1455.00	5700.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	5.00	0.00
89b82af8-072a-4977-8d1f-da69c96e39d8	6d29d8b3-9777-4a01-8431-53acbcad9363	c41a6043-e460-480b-a569-430c96d00541	2025-10-31	436	10900.00	16	2240.00	2025-11-02 16:47:36.241747+06	clw/19/2025/10H2	Due	12	0	\N	0.00	10900.00	4330.00	6570.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
7a2ff977-249f-4061-bee5-371c377e476d	3869bce6-8e5d-4e64-9197-24400000d168	01e5be66-b965-4adb-bc9a-2cfa16954161	2025-10-31	1804	45100.00	112	12320.00	2025-11-02 16:55:05.975066+06	clw/17/2025/10H2	Due	84	-17	\N	2255.00	42845.00	14499.38	28345.63	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
09e86a21-078c-44b6-9543-59deea61a494	07490f7a-5244-4e67-bcc0-4fd1df88ed92	3002befd-50db-4aca-964e-9476d0521850	2025-10-31	188	4700.00	9	1260.00	2025-11-02 18:19:16.255964+06	clw/23/2025/10H2	Due	31	-2	\N	0.00	4700.00	1634.00	3066.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
26789a34-c804-4af0-b60c-700d22deaf32	ee68bac1-c967-4b3e-be4c-53aeba1f1249	c41a6043-e460-480b-a569-430c96d00541	2025-10-31	416	10400.00	29	4060.00	2025-11-03 18:14:41.89426+06	clw/11/2025/10H2	Due	1	-6	\N	0.00	10400.00	3170.00	7230.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
a47a0b58-1e18-4034-926f-bc832163c53f	2fd45c00-2dce-471f-a4d8-f5ede2d712c4	29248edb-d4a3-4a78-9800-a10f60ad3488	2025-10-31	1120	28000.00	98	12740.00	2025-11-03 18:57:20.432031+06	clw/01/2025/10	Due	36	-26	\N	0.00	28000.00	6104.00	18844.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
84ad0a5e-6e6b-4fba-a8a1-cabdacbb2841	d3e8eb14-b460-4f82-b334-790165c2a922	c41a6043-e460-480b-a569-430c96d00541	2025-10-31	96	2400.00	3	420.00	2025-11-04 11:15:03.556284+06	clw/18/2025/10H2	Due	27	0	\N	0.00	2400.00	990.00	1410.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
eda4423b-6f0e-4741-81af-44cf7abebc6f	1885a455-019b-43d3-80e6-7a4fcc1e1232	9bbb9704-569c-4293-bbf8-df983d8ed37b	2025-11-12	144	3600.00	16	2240.00	2025-11-12 16:08:02.652737+06	clw/21/2025/11	Due	11	-4	\N	0.00	3600.00	612.00	2988.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
4780ac53-7c57-4aaa-bdeb-c848430566c8	ee68bac1-c967-4b3e-be4c-53aeba1f1249	c41a6043-e460-480b-a569-430c96d00541	2025-11-15	280	7000.00	13	1820.00	2025-11-16 10:43:31.563266+06	clw/11/2025/11H1	Due	1	-2	\N	0.00	7000.00	2590.00	4410.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
4738565c-35bc-4fb5-a7c5-9c1b3c33cab4	4f9ad276-ec83-423b-bb6a-3431e5b5d74f	c41a6043-e460-480b-a569-430c96d00541	2025-11-15	298	7450.00	8	1120.00	2025-11-16 10:45:48.630003+06	clw/14/2025/11H1	Due	14	0	\N	0.00	7450.00	3165.00	4285.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
c574b35c-95bd-4b8e-b9c7-7c0902cd843a	bf03337a-93fd-45a5-84c1-79fb21d59745	643bfd3f-24b6-491c-bed7-2d7d17968924	2025-11-15	340	8500.00	32	4800.00	2025-11-16 10:56:41.092888+06	clw/15/2025/11H1	Due	24	-2	\N	0.00	8500.00	1665.00	6666.25	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
c62ab849-ee33-46d6-b35e-e6cf25bcb920	277b890a-f8fe-4cb2-a106-066731d848e3	ab390752-da90-4d3f-9a9d-1f2f4b2f5eae	2025-11-15	156	3900.00	9	1170.00	2025-11-16 12:09:30.035538+06	clw/16/2025/11H1	Due	51	-3	\N	0.00	3900.00	1296.75	2525.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
1617e0a9-2714-48b0-ba78-d0a5d1df38bb	d5a1699b-e816-4560-b055-433d69949c23	9f092d84-60ed-481b-9466-ec5862e4acf9	2025-11-15	784	19600.00	37	5550.00	2025-11-16 12:53:32.781897+06	clw/22/2025/11H1	Due	1	0	\N	0.00	19600.00	8430.00	13812.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
96171229-26ad-4df5-85b8-30a55c189ef1	74077ddb-cbfc-46de-a0b6-1e2d1b68e4aa	cd9b585a-fefd-44bf-a97e-7d9b3624126d	2025-11-15	426	10650.00	35	5250.00	2025-11-16 13:18:39.460771+06	clw/05/2025/11H1	Due	2	33	\N	532.50	10117.50	2433.75	7433.75	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
953ef75f-fb02-44dd-8a7e-932f24e6d26d	4c5dda16-9682-4bba-aed0-c38e82ec5356	5ff5d038-a23e-431e-a26c-e98a0bcac2ed	2025-11-15	344	8600.00	13	1950.00	2025-11-16 14:43:37.221689+06	clw/24/2025/11H1	Due	0	-1	\N	0.00	8600.00	2992.50	5438.75	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
d57271bb-e5ba-4795-a591-de362169f4ee	3531f437-b29d-4f5c-8891-2463ae8e70b5	cd9b585a-fefd-44bf-a97e-7d9b3624126d	2025-11-15	850	21250.00	22	3300.00	2025-11-16 15:06:43.533197+06	clw/04/2025/11H1	Due	50	0	\N	1062.50	20187.50	8443.75	11493.75	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
142a358b-9c9d-48ed-a1a8-c3e8eadbb319	07490f7a-5244-4e67-bcc0-4fd1df88ed92	3002befd-50db-4aca-964e-9476d0521850	2025-11-15	348	8700.00	9	1260.00	2025-11-16 16:26:59.546128+06	clw/29/2025/11H1	Due	29	-3	\N	0.00	8700.00	3534.00	5166.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
6c059588-5ef1-4954-995a-b8472bb70267	b5327e30-7b83-4fda-99aa-99a107bbcca9	cd9b585a-fefd-44bf-a97e-7d9b3624126d	2025-11-15	1944	48600.00	146	21900.00	2025-11-16 18:28:09.926834+06	clw/06/2025/11H1	Due	300	0	\N	2430.00	46170.00	12135.00	33785.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
8742c1ad-3033-4c61-b60e-247cab753def	b873dc83-b55c-4fdc-98b9-7dc25e9d5a10	c41a6043-e460-480b-a569-430c96d00541	2025-11-15	180	4500.00	13	1820.00	2025-11-16 18:54:16.915897+06	clw/12/2025/11H1	Due	0	-1	\N	0.00	4500.00	1340.00	3160.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
c623e8b0-6e14-442f-a666-26dfca787578	29e89cc6-04f5-475d-8dd7-c2efe05d4c55	c41a6043-e460-480b-a569-430c96d00541	2025-11-15	188	4700.00	14	1960.00	2025-11-17 11:31:56.614885+06	clw/13/2025/11H1	Due	7	0	\N	0.00	4700.00	1370.00	3330.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
e1f6fb47-7a4e-471b-8143-8a838a871110	feb921c1-425c-4a8a-8748-f7d958a7d3e0	c9168bd5-0b15-49dc-9a35-cc5b52535600	2025-11-15	177	5310.00	13	1950.00	2025-11-17 11:57:43.157939+06	clw/27/2025/11H1	Due	180	0	\N	0.00	5310.00	2016.00	3966.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
49e9f5f2-a1d7-444c-871c-863fda247d50	b957c84b-8cc1-4ee9-a24c-a80565676721	c9168bd5-0b15-49dc-9a35-cc5b52535600	2025-11-15	453	13590.00	25	3750.00	2025-11-17 12:08:03.549806+06	clw/28/2025/11H1	Due	253	0	\N	0.00	13590.00	5904.00	9654.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
4fd45151-0731-4c86-a6f4-c1a0ff6ba480	6d29d8b3-9777-4a01-8431-53acbcad9363	c41a6043-e460-480b-a569-430c96d00541	2025-11-15	256	6400.00	13	1820.00	2025-11-17 16:41:52.4473+06	clw/19/2025/11H1	Due	5	-3	\N	0.00	6400.00	2290.00	4110.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
a5936ae7-ab7c-43a2-acd8-4916c63172eb	72cbe2e1-4a91-425e-8a53-71533ffbdb0e	d2f93e6d-44a3-4fbf-9a2b-e74661e0ea7a	2025-11-15	244	6100.00	14	2100.00	2025-11-19 13:45:52.774408+06	clw/26/2025/11H1	Due	138	1	\N	0.00	6100.00	1800.00	4131.25	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
9502e834-312f-4841-84ed-e4474ac07177	dfbbdc7f-e2de-4351-be66-4a05ee1aa6ed	c754765f-279d-4800-88dd-c08b89803b36	2025-11-15	260	6500.00	7	1050.00	2025-11-16 11:33:37.408618+06	clw/20/2025/11	Due	75	0		0.00	6500.00	2725.00	3774.50	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.50	0.00
b981b6b1-24cd-4fe2-b7cf-1154bba0b7cd	3869bce6-8e5d-4e64-9197-24400000d168	01e5be66-b965-4adb-bc9a-2cfa16954161	2025-11-15	1398	34950.00	84	9240.00	2025-11-19 18:48:16.957622+06	clw/17/2025/11H1	Due	39	-29	\N	1747.50	33202.50	11382.19	21820.31	b61a9829-5b43-41bc-b09a-3d74a0e05767	0.00	0.00
78782288-7419-4f68-bbe3-377e0eac6944	72cbe2e1-4a91-425e-8a53-71533ffbdb0e	d2f93e6d-44a3-4fbf-9a2b-e74661e0ea7a	2025-10-31	244	6100.00	7	1050.00	2025-11-04 11:08:55.708675+06	clw/26/2025/10H2	Due	93	10		0.00	6100.00	2525.00	3405.50	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.75	0.00
1f19dc8a-8804-4820-9371-367147438041	6ee6ed8e-bff1-43d0-a29b-1764668b2b29	29248edb-d4a3-4a78-9800-a10f60ad3488	2025-10-31	1800	45000.00	112	14560.00	2025-11-03 19:04:44.909812+06	clw/03/2025/10	Due	99	-19		0.00	45000.00	12176.00	26736.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	0.00	0.00
3c9859bc-2442-4046-ad2b-fb4169cae9f4	6f603dc0-90ac-4d7d-ac3a-ee7bfe9557c8	29248edb-d4a3-4a78-9800-a10f60ad3488	2025-10-31	896	22400.00	60	7800.00	2025-11-22 16:46:55.148139+06	clw/02/2025/10	Due	10	-25		0.00	22400.00	5840.00	13620.00	d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	20.00	0.00
\.


--
-- Data for Name: stock_out_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_out_history (id, out_date, machine_id, item_id, quantity, remarks, handled_by, created_at, updated_at, adjustment_type, category, item_name, unit_price, total_price) FROM stdin;
c0e20745-a1ad-477e-ab22-ca9ec9d24d81	2025-10-29	3531f437-b29d-4f5c-8891-2463ae8e70b5	396e59cb-91bd-433e-90d2-f56ea4201823	1	sticker change	System	2025-11-14 20:42:36.578257	2025-11-14 20:42:36.578257	\N	\N	\N	\N	\N
4e67eed0-8c69-40a0-88f6-5d3230b680c5	2025-11-13	b5327e30-7b83-4fda-99aa-99a107bbcca9	4b9ff4a9-7437-45ff-8b38-6f88cbc1b22e	1	Cafe rio mirpur sicker chaange 	System	2025-11-14 19:43:07.016079	2025-11-14 19:43:07.016079	\N	\N	\N	\N	\N
192b877a-d632-48d3-8adb-7f1b3f7cce63	2025-10-28	d5a1699b-e816-4560-b055-433d69949c23	d92d0c81-4fa8-400f-abe5-7a0f7b7ef983	3	for agreement	System	2025-11-14 20:33:34.966843	2025-11-14 20:33:34.966843	\N	\N	\N	\N	\N
bfbe3fe6-26a8-4968-a100-f90fefa3e95b	2025-10-29	d5a1699b-e816-4560-b055-433d69949c23	a009d560-3692-4313-9986-2daa5b3f1f56	1		\N	2025-11-16 14:29:40.761537	2025-11-16 14:29:40.761537	\N	\N	\N	\N	\N
00b3b08f-1e6b-4b73-ba56-8a4d5365761d	2025-11-19	\N	\N	3	Stock In	\N	2025-11-20 14:09:38.021405	2025-11-20 14:09:38.021405	stock_in	Local Accessories	Esp32	440.00	1320.00
13147351-21a2-452a-acdb-b903a623f827	2025-11-20	07490f7a-5244-4e67-bcc0-4fd1df88ed92	\N	43		\N	2025-11-20 14:53:36.969946	2025-11-20 14:53:36.969946	doll_add	\N	\N	\N	\N
f052efcd-655b-436d-a709-6826a4eec067	2025-11-20	1885a455-019b-43d3-80e6-7a4fcc1e1232	\N	63		\N	2025-11-20 14:53:50.403756	2025-11-20 14:53:50.403756	doll_add	\N	\N	\N	\N
f36a399d-e777-42e3-8f17-ec872293c4a0	2025-11-20	4c5dda16-9682-4bba-aed0-c38e82ec5356	\N	80		\N	2025-11-20 14:54:27.110646	2025-11-20 14:54:27.110646	doll_add	\N	\N	\N	\N
a4bad196-eee3-4bbe-827d-5e4d848b2220	2025-11-20	d3e8eb14-b460-4f82-b334-790165c2a922	\N	46		\N	2025-11-20 15:01:50.971044	2025-11-20 15:01:50.971044	doll_add	\N	\N	\N	\N
47233239-4a7e-4623-91cd-db50834b1264	2025-11-20	6d29d8b3-9777-4a01-8431-53acbcad9363	\N	92		\N	2025-11-20 15:02:17.51759	2025-11-20 15:02:17.51759	doll_add	\N	\N	\N	\N
6629b42a-614c-496d-8056-b74f5b8293ea	2025-11-20	72cbe2e1-4a91-425e-8a53-71533ffbdb0e	\N	5		\N	2025-11-20 15:02:49.988105	2025-11-20 15:02:49.988105	doll_add	\N	\N	\N	\N
ac67e7cd-9d20-46b8-ba7e-689c64f592ea	2025-11-20	b957c84b-8cc1-4ee9-a24c-a80565676721	\N	99		\N	2025-11-20 15:03:10.756721	2025-11-20 15:03:10.756721	doll_add	\N	\N	\N	\N
742aab83-7391-422d-b25b-cdd000cecbfb	2025-11-20	b957c84b-8cc1-4ee9-a24c-a80565676721	\N	29		\N	2025-11-20 15:04:07.669351	2025-11-20 15:04:07.669351	doll_add	\N	\N	\N	\N
672badab-8a2d-49be-9932-339ffa686deb	2025-11-20	feb921c1-425c-4a8a-8748-f7d958a7d3e0	\N	31		\N	2025-11-20 15:04:19.323491	2025-11-20 15:04:19.323491	doll_add	\N	\N	\N	\N
253b5f86-d3f8-46fc-acbd-49f843acda87	2025-11-20	dfbbdc7f-e2de-4351-be66-4a05ee1aa6ed	\N	100		\N	2025-11-20 15:04:49.428714	2025-11-20 15:04:49.428714	doll_add	\N	\N	\N	\N
14a64f23-909a-400e-a65c-4c9c8694382e	2025-11-20	bf03337a-93fd-45a5-84c1-79fb21d59745	\N	172		\N	2025-11-20 15:05:11.48544	2025-11-20 15:05:11.48544	doll_add	\N	\N	\N	\N
8fb2daca-5cd4-4bbb-8b48-2dbee1588f64	2025-11-20	277b890a-f8fe-4cb2-a106-066731d848e3	\N	69		\N	2025-11-20 15:05:44.000327	2025-11-20 15:05:44.000327	doll_add	\N	\N	\N	\N
94c4e86a-88fc-408d-ac67-82f01e91adad	2025-11-20	b873dc83-b55c-4fdc-98b9-7dc25e9d5a10	\N	15		\N	2025-11-20 15:06:09.693291	2025-11-20 15:06:09.693291	doll_add	\N	\N	\N	\N
160b55f7-b685-4edb-9868-2534e9d04417	2025-11-20	ee68bac1-c967-4b3e-be4c-53aeba1f1249	\N	133		\N	2025-11-20 15:06:31.115067	2025-11-20 15:06:31.115067	doll_add	\N	\N	\N	\N
d30c2238-5367-48a8-a491-1c7cc6bfcb2c	2025-11-20	4f9ad276-ec83-423b-bb6a-3431e5b5d74f	\N	84		\N	2025-11-20 15:07:45.061341	2025-11-20 15:07:45.061341	doll_add	\N	\N	\N	\N
cc1903e0-5de3-41b7-bf67-864164379a09	2025-11-20	4f9ad276-ec83-423b-bb6a-3431e5b5d74f	\N	10		\N	2025-11-20 15:08:10.700195	2025-11-20 15:08:10.700195	doll_add	\N	\N	\N	\N
0e571bd5-7f03-44d4-9e60-2dc8e792d7ba	2025-11-20	29e89cc6-04f5-475d-8dd7-c2efe05d4c55	\N	63		\N	2025-11-20 15:08:30.423191	2025-11-20 15:08:30.423191	doll_add	\N	\N	\N	\N
183017ea-99e7-4af5-a3ac-b63bd92b8b8c	2025-11-20	3869bce6-8e5d-4e64-9197-24400000d168	\N	123		\N	2025-11-20 15:08:54.937683	2025-11-20 15:08:54.937683	doll_add	\N	\N	\N	\N
6cfcb7b7-1b32-4c23-a018-33b2d71fee70	2025-11-20	b084d7e5-1c69-4d42-9650-3b2ee45443d3	\N	75		\N	2025-11-20 15:09:29.217906	2025-11-20 15:09:29.217906	doll_add	\N	\N	\N	\N
7e01ac29-6fb1-4380-81a2-c241b82b3b55	2025-11-20	ae0f877f-a5b4-4955-a295-317855b3ff27	\N	134		\N	2025-11-20 15:09:50.941031	2025-11-20 15:09:50.941031	doll_add	\N	\N	\N	\N
e012eabb-18a1-4d03-b111-a97e1aac29a4	2025-11-20	8cb8bd6f-be4d-4964-8e10-eddd392cff87	\N	92		\N	2025-11-20 15:10:16.645592	2025-11-20 15:10:16.645592	doll_add	\N	\N	\N	\N
74f17020-c09f-465e-b304-3cc72e0fce4c	2025-11-20	aa75ca99-9bf5-4156-af35-4467c84f44fd	\N	67		\N	2025-11-20 15:10:38.287291	2025-11-20 15:10:38.287291	doll_add	\N	\N	\N	\N
ed77c750-3b19-492a-bdee-9f0a0dd1c29f	2025-11-20	74077ddb-cbfc-46de-a0b6-1e2d1b68e4aa	\N	51		\N	2025-11-20 15:15:08.828157	2025-11-20 15:15:08.828157	doll_add	\N	\N	\N	\N
d1a272d1-af92-43eb-a213-2aac87cd4879	2025-11-20	74077ddb-cbfc-46de-a0b6-1e2d1b68e4aa	\N	136		\N	2025-11-20 15:15:34.912127	2025-11-20 15:15:34.912127	doll_add	\N	\N	\N	\N
0950f68f-0101-4b66-b8fe-afb23f411b3e	2025-11-20	3531f437-b29d-4f5c-8891-2463ae8e70b5	\N	141		\N	2025-11-20 15:15:54.459979	2025-11-20 15:15:54.459979	doll_add	\N	\N	\N	\N
ad43fbb2-4198-42c0-9740-b40902c475c1	2025-11-20	b5327e30-7b83-4fda-99aa-99a107bbcca9	\N	93		\N	2025-11-20 15:16:15.280938	2025-11-20 15:16:15.280938	doll_add	\N	\N	\N	\N
570382a2-93b4-4bb0-8032-ea5e3218b3be	2025-11-20	6ee6ed8e-bff1-43d0-a29b-1764668b2b29	\N	206		\N	2025-11-20 15:16:41.385346	2025-11-20 15:16:41.385346	doll_add	\N	\N	\N	\N
0b86457b-da85-4b08-9612-090edd78148d	2025-11-20	6ee6ed8e-bff1-43d0-a29b-1764668b2b29	\N	-100		\N	2025-11-20 15:17:05.097763	2025-11-20 15:17:05.097763	doll_deduct	\N	\N	\N	\N
d7e6cd7e-eec2-4466-b6c7-e9eb33498c39	2025-11-20	6f603dc0-90ac-4d7d-ac3a-ee7bfe9557c8	\N	92		\N	2025-11-20 15:17:29.473764	2025-11-20 15:17:29.473764	doll_add	\N	\N	\N	\N
10f6db57-e553-4110-ad1a-2757709b460d	2025-11-20	2fd45c00-2dce-471f-a4d8-f5ede2d712c4	\N	32		\N	2025-11-20 15:17:52.601948	2025-11-20 15:17:52.601948	doll_add	\N	\N	\N	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, name, password_hash, role, franchise_id, created_at, first_name, last_name, username) FROM stdin;
48de882b-bc22-4521-9f55-fe9011b68e20	jrrafi16@gmail.com	Rafi	$2b$10$I3KNn5NBiNFY2AA8LIqZB.1DEGpkClOy11f4n7t3N1bFrwo.yJd3m	admin	\N	2025-09-29 16:49:33.232587+06	Md. Ariful	Islam	jrrafi11
b61a9829-5b43-41bc-b09a-3d74a0e05767	admin@clowee.com	Clowee Admin	$2b$10$LA/TIp/FiCLwXWm6lDXwDOpR/YIBvZguFE2S6J/ScfuzjuMpucJcO	admin	\N	2025-09-29 12:57:39.400135+06	Clowee	Admin	clowee_admin
b0f6f617-9414-4a96-9e45-3a7ecc7957d3	sohel@sohub.com.bd	Md Sohel Rana	$2b$10$fEhtjBVa0xWrVkuza2GKJeTX9DnEkmKxo09qBVntL.tu89CJ/Yfuq	admin	\N	2025-10-21 11:40:01.896554+06	\N	\N	\N
d47a8b5b-567f-40d3-9f7f-f2341b3a5d27	sajibur@sohub.com.bd	Sajibur Rahman	$2b$10$p8csRP8UqTSsKcnwLkzOee7JLGVQvHYUAx8PjQkmjcvFGYHn7ct/m	admin	\N	2025-10-19 15:54:29.085382+06	Md Sajibur	Rahman	\N
0bdac82c-42e0-4061-a269-47a34ef457b2	spectator01@clowee.com	Spectator_Tester	$2b$10$o4ls9LiLsvNKq4DeFXbL.eAbXzd0hAlX8TzJ9hFibH680pxqdLgVK	spectator	\N	2025-10-15 16:48:43.49989+06	\N	\N	\N
12ad4585-93b8-4559-b76b-9b4ff2dabc9a	superadmin@clowee.com	Super Admin	$2b$10$sQ6qwAaxpvuLIFBs2g4nFO0BPuBoUD62Z8bpUfWzCPLtQ9tQPESbi	super_admin	\N	2025-10-27 23:23:39.016352+06	Super	Admin	superadmin
975b7b9b-f608-45c0-861d-d91695ec79e9	sharif@sohub.com.bd	Md Arman Al Sharif	$2b$10$CxetNWGYZSrvp3kWZ6SKROUQTbr0Ym/gKE3A7EoCb/rCY7wilsXOi	admin	\N	2025-10-19 15:57:13.029986+06	\N	\N	\N
916fa33b-6f04-4964-8413-391bafe60bf1	rafid@sohub.com.bd	Rafid	$2b$10$YlkFBEjr.Zw9pbUyXlduaOMXyr9Zdm7kDtyHxGvr9Avgq58/lyOQq	user	\N	2025-11-20 14:00:15.558161+06	\N	\N	\N
\.


--
-- Name: expense_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.expense_categories_id_seq', 23, true);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: bank_money_logs bank_money_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_money_logs
    ADD CONSTRAINT bank_money_logs_pkey PRIMARY KEY (id);


--
-- Name: banks banks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banks
    ADD CONSTRAINT banks_pkey PRIMARY KEY (id);


--
-- Name: expense_categories expense_categories_category_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_category_name_key UNIQUE (category_name);


--
-- Name: expense_categories expense_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_pkey PRIMARY KEY (id);


--
-- Name: franchise_agreements franchise_agreements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.franchise_agreements
    ADD CONSTRAINT franchise_agreements_pkey PRIMARY KEY (id);


--
-- Name: franchises franchises_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.franchises
    ADD CONSTRAINT franchises_pkey PRIMARY KEY (id);


--
-- Name: inventory_transactions inventory_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_pkey PRIMARY KEY (id);


--
-- Name: ledger_entries ledger_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ledger_entries
    ADD CONSTRAINT ledger_entries_pkey PRIMARY KEY (id);


--
-- Name: machine_counters machine_counters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.machine_counters
    ADD CONSTRAINT machine_counters_pkey PRIMARY KEY (id);


--
-- Name: machine_expenses machine_expenses_expense_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.machine_expenses
    ADD CONSTRAINT machine_expenses_expense_number_key UNIQUE (expense_number);


--
-- Name: machine_expenses machine_expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.machine_expenses
    ADD CONSTRAINT machine_expenses_pkey PRIMARY KEY (id);


--
-- Name: machine_payments machine_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.machine_payments
    ADD CONSTRAINT machine_payments_pkey PRIMARY KEY (id);


--
-- Name: machines machines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.machines
    ADD CONSTRAINT machines_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: price_history price_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_pkey PRIMARY KEY (id);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (id);


--
-- Name: stock_out_history stock_out_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_out_history
    ADD CONSTRAINT stock_out_history_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_logs_table_record; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_table_record ON public.audit_logs USING btree (table_name, record_id);


--
-- Name: idx_bank_money_logs_bank_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bank_money_logs_bank_id ON public.bank_money_logs USING btree (bank_id);


--
-- Name: idx_bank_money_logs_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bank_money_logs_date ON public.bank_money_logs USING btree (transaction_date);


--
-- Name: idx_franchises_payment_bank_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_franchises_payment_bank_id ON public.franchises USING btree (payment_bank_id);


--
-- Name: idx_inventory_transactions_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inventory_transactions_item_id ON public.inventory_transactions USING btree (item_id);


--
-- Name: idx_machine_counters_machine_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_machine_counters_machine_id ON public.machine_counters USING btree (machine_id);


--
-- Name: idx_machine_expenses_bank_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_machine_expenses_bank_id ON public.machine_expenses USING btree (bank_id);


--
-- Name: idx_machine_expenses_machine_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_machine_expenses_machine_id ON public.machine_expenses USING btree (machine_id);


--
-- Name: idx_machine_payments_invoice_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_machine_payments_invoice_id ON public.machine_payments USING btree (invoice_id);


--
-- Name: idx_machine_payments_machine_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_machine_payments_machine_id ON public.machine_payments USING btree (machine_id);


--
-- Name: idx_machines_franchise_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_machines_franchise_id ON public.machines USING btree (franchise_id);


--
-- Name: idx_notifications_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_created_at ON public.notifications USING btree (created_at DESC);


--
-- Name: idx_notifications_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_status ON public.notifications USING btree (status);


--
-- Name: idx_notifications_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: idx_sales_franchise_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sales_franchise_id ON public.sales USING btree (franchise_id);


--
-- Name: idx_sales_invoice_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sales_invoice_number ON public.sales USING btree (invoice_number);


--
-- Name: idx_sales_machine_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sales_machine_id ON public.sales USING btree (machine_id);


--
-- Name: idx_sales_payment_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sales_payment_status ON public.sales USING btree (payment_status);


--
-- Name: idx_stock_out_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_out_date ON public.stock_out_history USING btree (out_date);


--
-- Name: idx_stock_out_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_out_item_id ON public.stock_out_history USING btree (item_id);


--
-- Name: idx_stock_out_machine_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_out_machine_id ON public.stock_out_history USING btree (machine_id);


--
-- Name: sales trigger_auto_invoice_number; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_auto_invoice_number BEFORE INSERT ON public.sales FOR EACH ROW EXECUTE FUNCTION public.auto_generate_invoice_number();


--
-- Name: attachments attachments_franchise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_franchise_id_fkey FOREIGN KEY (franchise_id) REFERENCES public.franchises(id);


--
-- Name: audit_logs audit_logs_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id);


--
-- Name: bank_money_logs bank_money_logs_bank_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_money_logs
    ADD CONSTRAINT bank_money_logs_bank_id_fkey FOREIGN KEY (bank_id) REFERENCES public.banks(id) ON DELETE CASCADE;


--
-- Name: users fk_users_franchise; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_franchise FOREIGN KEY (franchise_id) REFERENCES public.franchises(id);


--
-- Name: franchise_agreements franchise_agreements_franchise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.franchise_agreements
    ADD CONSTRAINT franchise_agreements_franchise_id_fkey FOREIGN KEY (franchise_id) REFERENCES public.franchises(id);


--
-- Name: franchises franchises_payment_bank_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.franchises
    ADD CONSTRAINT franchises_payment_bank_id_fkey FOREIGN KEY (payment_bank_id) REFERENCES public.banks(id);


--
-- Name: machine_counters machine_counters_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.machine_counters
    ADD CONSTRAINT machine_counters_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: machine_counters machine_counters_machine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.machine_counters
    ADD CONSTRAINT machine_counters_machine_id_fkey FOREIGN KEY (machine_id) REFERENCES public.machines(id);


--
-- Name: machine_expenses machine_expenses_bank_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.machine_expenses
    ADD CONSTRAINT machine_expenses_bank_id_fkey FOREIGN KEY (bank_id) REFERENCES public.banks(id);


--
-- Name: machine_expenses machine_expenses_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.machine_expenses
    ADD CONSTRAINT machine_expenses_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.expense_categories(id);


--
-- Name: machine_expenses machine_expenses_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.machine_expenses
    ADD CONSTRAINT machine_expenses_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: machine_expenses machine_expenses_machine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.machine_expenses
    ADD CONSTRAINT machine_expenses_machine_id_fkey FOREIGN KEY (machine_id) REFERENCES public.machines(id);


--
-- Name: machine_payments machine_payments_bank_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.machine_payments
    ADD CONSTRAINT machine_payments_bank_id_fkey FOREIGN KEY (bank_id) REFERENCES public.banks(id);


--
-- Name: machine_payments machine_payments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.machine_payments
    ADD CONSTRAINT machine_payments_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: machine_payments machine_payments_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.machine_payments
    ADD CONSTRAINT machine_payments_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.sales(id);


--
-- Name: machine_payments machine_payments_machine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.machine_payments
    ADD CONSTRAINT machine_payments_machine_id_fkey FOREIGN KEY (machine_id) REFERENCES public.machines(id);


--
-- Name: machines machines_franchise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.machines
    ADD CONSTRAINT machines_franchise_id_fkey FOREIGN KEY (franchise_id) REFERENCES public.franchises(id);


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: price_history price_history_franchise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_franchise_id_fkey FOREIGN KEY (franchise_id) REFERENCES public.franchises(id);


--
-- Name: sales sales_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: sales sales_franchise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_franchise_id_fkey FOREIGN KEY (franchise_id) REFERENCES public.franchises(id);


--
-- Name: sales sales_machine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_machine_id_fkey FOREIGN KEY (machine_id) REFERENCES public.machines(id);


--
-- Name: stock_out_history stock_out_history_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_out_history
    ADD CONSTRAINT stock_out_history_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.machine_expenses(id);


--
-- Name: stock_out_history stock_out_history_machine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_out_history
    ADD CONSTRAINT stock_out_history_machine_id_fkey FOREIGN KEY (machine_id) REFERENCES public.machines(id);


--
-- PostgreSQL database dump complete
--

\unrestrict RexRrAuY1MRx7cXieJPggk8sbPuPWOp3jsP8obLPIl13AuxiVsmgMg2HapBNM4U

